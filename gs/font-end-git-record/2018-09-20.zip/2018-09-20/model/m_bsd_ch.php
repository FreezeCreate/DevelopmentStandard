<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_bsd_ch extends spModel{
    var $pk = "id";
    var $table = "bsd_ch";
    
    
}

?>
