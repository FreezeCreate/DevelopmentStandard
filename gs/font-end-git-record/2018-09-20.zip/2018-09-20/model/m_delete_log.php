<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_delete_log extends spModel{
    var $pk = "id";
    var $table = "delete_log";
    
    
    
}

?>
