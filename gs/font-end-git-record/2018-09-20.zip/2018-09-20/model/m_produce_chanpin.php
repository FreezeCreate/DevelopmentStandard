<?php

/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_produce_chanpin extends spModel {

    var $pk = "id";
    var $table = "produce_chanpin";


}

?>
