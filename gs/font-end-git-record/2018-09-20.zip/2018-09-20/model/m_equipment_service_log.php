<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_equipment_service_log extends spModel{
    var $pk = "id";
    var $table = "equipment_service_log";
    
    
}

?>
