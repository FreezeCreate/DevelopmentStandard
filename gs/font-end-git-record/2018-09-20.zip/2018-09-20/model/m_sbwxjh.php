<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_sbwxjh extends spModel{
    var $pk = "id";
    var $table = "sbwxjh";
    
    
}

?>
