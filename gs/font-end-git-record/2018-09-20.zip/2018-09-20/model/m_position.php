<?php

/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_position extends spModel {

    var $pk = "id";
    var $table = "position";


}

?>
