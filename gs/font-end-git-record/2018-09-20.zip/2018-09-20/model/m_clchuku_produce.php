<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_clchuku_produce extends spModel{
    var $pk = "id";
    var $table = "clchuku_produce";
    
    
}

?>
