<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_myofficeapl extends spModel{
    var $pk = "id";
    var $table = "myofficeapl";
    
    
    
}

?>
