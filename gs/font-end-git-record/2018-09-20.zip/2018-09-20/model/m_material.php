<?php

/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_material extends spModel {

    var $pk = "id";
    var $table = "material";


}

?>
