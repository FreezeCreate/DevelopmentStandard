<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_custmang extends spModel{
    var $pk = "id";
    var $table = "custmang";
    
    
}

?>
