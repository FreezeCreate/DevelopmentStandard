<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_draw_mater extends spModel{
    var $pk = "id";
    var $table = "draw_mater";
    
    
    
}

?>
