<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_fankui extends spModel{
    var $pk = "id";
    var $table = "fankui";
    
    
}

?>
