<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_nbshjh extends spModel{
    var $pk = "id";
    var $table = "nbshjh";
    
    
}

?>
