<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_sbtz_log extends spModel{
    var $pk = "id";
    var $table = "sbtz_log";
    
    
}

?>
