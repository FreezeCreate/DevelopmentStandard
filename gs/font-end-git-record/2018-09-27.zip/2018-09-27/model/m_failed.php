<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_failed extends spModel{
    var $pk = "id";
    var $table = "failed";
    
}

?>
