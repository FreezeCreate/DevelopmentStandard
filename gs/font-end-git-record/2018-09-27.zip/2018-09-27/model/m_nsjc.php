<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_nsjc extends spModel{
    var $pk = "id";
    var $table = "nsjc";
    
    
}

?>
