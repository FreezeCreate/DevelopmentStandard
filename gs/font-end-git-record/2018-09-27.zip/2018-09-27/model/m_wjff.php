<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_wjff extends spModel{
    var $pk = "id";
    var $table = "wjff";
    
    
}

?>
