<?php

/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_purchase_caigou_mater extends spModel {

    var $pk = "id";
    var $table = "purchase_caigou_mater";

}

?>
