<?php

/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_zxlog_shebei extends spModel {

    var $pk = "id";
    var $table = "zxlog_shebei";

}

?>
