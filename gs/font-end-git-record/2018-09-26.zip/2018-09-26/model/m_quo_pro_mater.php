<?php

/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_quo_pro_mater extends spModel {

    var $pk = "id";
    var $table = "quo_pro_mater";
    


}

?>
