<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_sbwxjh_ch extends spModel{
    var $pk = "id";
    var $table = "sbwxjh_ch";
    
    
}

?>
