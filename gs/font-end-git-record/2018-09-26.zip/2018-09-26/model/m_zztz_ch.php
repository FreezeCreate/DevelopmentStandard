<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_zztz_ch extends spModel{
    var $pk = "id";
    var $table = "zztz_ch";
    
    
}

?>
