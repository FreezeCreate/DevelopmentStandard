<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_device_desc extends spModel{
    var $pk = "id";
    var $table = "device_desc";
    
    
}

?>
