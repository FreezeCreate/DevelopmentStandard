<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_chuku_produce extends spModel{
    var $pk = "id";
    var $table = "chuku_produce";
    
    
}

?>
