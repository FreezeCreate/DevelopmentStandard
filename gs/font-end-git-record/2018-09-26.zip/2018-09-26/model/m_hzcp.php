<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_hzcp extends spModel{
    var $pk = "id";
    var $table = "hzcp";
    
    
}

?>
