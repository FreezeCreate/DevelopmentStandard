<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_sbbyjl extends spModel{
    var $pk = "id";
    var $table = "sbbyjl";
    
    
}

?>
