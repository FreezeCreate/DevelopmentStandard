<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_atdate extends spModel{
    var $pk = "id";
    var $table = "atdate";
    
    
}

?>
