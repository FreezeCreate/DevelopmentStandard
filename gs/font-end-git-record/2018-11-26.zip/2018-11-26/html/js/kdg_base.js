"use strict"
$(function(){
    // 汇报表名称
    $(".liveCateLst").each(function (i, e) {
        var that = $(e);
        showCommonList("app.php/service/liveCateLst", function (data) {
            if (data.code == 0) {
                var res = data.results, html = '<option   value="">--现场知识库类型--</option>';
                for (var i in res) {
                    html += '<option value="'+res[i].id+'">'+res[i].catename+'</option>';
                }
                that.html(html);

                getPagesBox({
                    nowUrl:"/app.php/service/liveConLst",
                    addList: function(data){
                        $(".noMsg").hide();
                        if(data.code!=0){
                            console.log(data.msg);
                            return false;
                        }
                        var res=data.results;
                        if(!res)return false;
                        var html='';
                        for(var i in res){//{id,live_title,live_desc,catename,live_adddt,optname}
                            html+='<tr title="'+res[i].live_desc+'">'+
                                    '<td>'+(Number(i)+1)+'</td>'+
                                    '<td>'+res[i].live_title+'</td>'+
                                    '<td>'+res[i].live_adddt+'</td>'+
                                    '<td>'+res[i].optname+'</td>'+
                                    '<td>'+
                                        '<div class="colorBlu list-menu" style="display: inline-block;">操作+'+
                                            '<ul class="menu">'+
                                                '<li data-url="service/liveConItem.html?id='+res[i].id+'" class="colorBlu menu-item NewPop" data-title="知识库详情">'+
                                                    '<a href="#">详情</a>'+
                                               ' </li>'+
                                                '<li data-url="service/updLiveCon.html?id='+res[i].id+'" class="colorBlu menu-item NewPop" data-title="修改知识库信息">'+
                                                    '<a href="#">修改</a>'+
                                                '</li>'+
                                                '<li class="colorRed delTr menu-item" data-cid="'+res[i].id+'">'+
                                                    '<a href="#">删除</a>'+
                                                '</li>'+
                                            '</ul>'+
                                        '</div>'+
                                    '</td>'+
                                '</tr>';
                        }
                        $("#dataList").html(html);
                    }
                });
            } else {
                console.error("网络错误！");
            }
        });
    });
});