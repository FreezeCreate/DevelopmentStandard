<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <style>
            div,a{font-family:"Microsoft YaHei",微软雅黑,"Microsoft JhengHei",华文细黑,宋体;}
            .box{width:1200px; height:454px; margin:100px auto 0px auto; background:url(<?php echo SOURCE_PATH;?>/img/404.png) no-repeat; position:relative;}
            .link{position:absolute; left:750px; top:350px;}
        </style>
    </head>
    <body>
        <div class="box">
            <div class="link">
                <a href="<?php echo spUrl("main","index"); ?>">返回首页</a>&nbsp;&nbsp;&nbsp;
                <a href="javascript:window.history.go(-1);" >返回上一页面</a>
            </div>
        </div>
    </body>
</html>
