<?php

/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_zxlog extends spModel {

    var $pk = "id";
    var $table = "zxlog";


}

?>
