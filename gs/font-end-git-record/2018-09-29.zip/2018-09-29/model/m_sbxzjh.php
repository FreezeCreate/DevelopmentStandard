<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_sbxzjh extends spModel{
    var $pk = "id";
    var $table = "sbxzjh";
    
    
}

?>
