<?php

/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_flow_bill extends spModel {

    var $pk = "id";
    var $table = "flow_bill";


}

?>
