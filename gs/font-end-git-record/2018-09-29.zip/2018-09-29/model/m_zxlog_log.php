<?php

/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_zxlog_log extends spModel {

    var $pk = "id";
    var $table = "zxlog_log";


}

?>
