<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_equipment extends spModel{
    var $pk = "id";
    var $table = "equipment";
    
    
}

?>
