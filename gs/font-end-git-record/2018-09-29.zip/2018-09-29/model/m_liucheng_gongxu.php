<?php
/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_liucheng_gongxu extends spModel{
    
    var $pk = "id";
    var $table = "liucheng_gongxu";
    
}
?>
