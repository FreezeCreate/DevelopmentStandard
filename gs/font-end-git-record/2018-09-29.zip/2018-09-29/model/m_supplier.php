<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_supplier extends spModel{
    var $pk = "id";
    var $table = "supplier";
    
    
}

?>
