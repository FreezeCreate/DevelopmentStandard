<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_sale_goal extends spModel{
    var $pk = "id";
    var $table = "sale_goal";
    
}

?>
