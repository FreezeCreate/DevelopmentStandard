$(()=>{
    console.log('login');
    $.ajax({
        type:"get",
        url:dataURL+"dailywork/dailyworkinfo/id/1?token="+dataToken,
        dataType:"json",
        data:{username:'admin',password:123456},
        success:function(data){
            console.log(data);
        },
        error:function(){
            alert("网络错误");
        }        
    });
    // 5523cbad2881cc1ea54a6b55083547c6a932eef2
});