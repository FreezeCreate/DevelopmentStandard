<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_custpay_mon extends spModel{
    var $pk = "id";
    var $table = "custpay_mon";
    
}

?>
