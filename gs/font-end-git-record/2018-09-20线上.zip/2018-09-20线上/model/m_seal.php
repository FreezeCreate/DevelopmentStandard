<?php

/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_seal extends spModel {

    var $pk = "id";
    var $table = "seal";


}

?>
