<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_customer extends spModel{
    var $pk = "id";
    var $table = "customer";
    
    
}

?>
