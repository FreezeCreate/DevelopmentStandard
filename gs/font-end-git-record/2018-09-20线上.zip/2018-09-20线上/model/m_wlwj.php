<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_wlwj extends spModel{
    var $pk = "id";
    var $table = "wlwj";
    
    
}

?>
