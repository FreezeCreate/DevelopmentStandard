<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_cust_record extends spModel{
    var $pk = "id";
    var $table = "cust_record";
    
    
}

?>
