<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_stock_room extends spModel{
    var $pk = "id";
    var $table = "stock_room";
    
    
}

?>
