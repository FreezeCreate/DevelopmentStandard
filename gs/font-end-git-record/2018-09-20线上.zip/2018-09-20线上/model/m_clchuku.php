<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_clchuku extends spModel{
    var $pk = "id";
    var $table = "clchuku";
    
    
}

?>
