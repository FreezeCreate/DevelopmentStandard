<?php
/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_role extends spModel{
    var $pk = "id";
    var $table = "role";
}
?>
