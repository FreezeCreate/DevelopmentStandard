<?php

/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_pro_mater extends spModel {

    var $pk = "id";
    var $table = "pro_mater";

}

?>
