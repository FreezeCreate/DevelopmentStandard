<?php

/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_quo_project extends spModel {

    var $pk = "id";
    var $table = "quo_project";
    


}

?>
