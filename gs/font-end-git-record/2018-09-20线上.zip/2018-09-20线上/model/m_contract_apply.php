<?php

/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_contract_apply extends spModel {

    var $pk = "id";
    var $table = "contract_apply";

}

?>
