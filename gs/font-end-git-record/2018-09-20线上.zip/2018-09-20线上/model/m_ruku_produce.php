<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_ruku_produce extends spModel{
    var $pk = "id";
    var $table = "ruku_produce";
    
    
}

?>
