$(()=>{
    "use strice"
    $('.xzwj').click(function() {
        $('.upfile').click()
    });
    function showIndex(oid){
        var html=`<li>
            <a class="MenuItem active on NewHtml a_01"data-url="home.html"data-clas="a_01"data-img="images/shouye_39.png"data-name="首页"data-url="home.html">
                <i class="firstImg home_1"></i>
                <span class="firstText">首页</span>
            </a>
        </li><li class='l_loading'></li>`;
        $("#LeftMenuBox").html(html);
        $.ajax({
            type:"get",
            data:{oid,token:dataToken},
            url:dataURL+"app.php/main/menuLst",
            dataType:"json",
            success:function(data){
               // console.log(data);
                if(data.code!=0){
                    console.log("加载失败！");
                    return false;
                }
                var html=`<li>
                    <a class="MenuItem active on NewHtml a_01"data-url="home.html"data-clas="a_01"data-img="images/shouye_39.png"data-name="首页"data-url="home.html">
                        <i class="firstImg home_1"></i>
                        <span class="firstText">首页</span>
                    </a>
                </li>`;
                var res=data.results,url='';
                if(!res)return false;
                for(var {id,title,control,way,children,img} of res){
                    var childHtml='',len=children.length;
                    url=len>0?control:(control+'/'+way);
                    if(len>0){
                        for(var i=0;i<len;i++){
                            childHtml+=`<a class="Second NewHtml" data-url="${children[i].control+'/'+children[i].way}.html" data-clas="a_${children[i].id}" data-name="${children[i].title}">
                                <i class="firstImg home_01"></i>
                                <span class="firstText">${children[i].title}</span>
                            </a>`;
                        }
                        html+=`<li class="MenuGroup">
                                <div class="GroupFirst">
                                    <i class="firstImg home_${img}"></i>
                                    <span class="firstText">${title}</span>
                                </div>
                                <div class="GroupFirstBox">${childHtml}</div>
                            </li>`;
                    }else{
                        html+=`<li>
                            <a class="MenuItem NewHtml" data-url="${url}.html" data-clas="a_${id}" data-name="${title}">
                                <i class="firstImg home_${img}"></i>
                                <span class="firstText">${title}</span>
                            </a>
                        </li>`;
                    }
                }
                $("#LeftMenuBox").html(html);
            },
            error(){alert("导航接口问题");}
        });
    }
    showIndex(1);
    $(".HeaderTitle li").click(function(e){
        e.preventDefault();
        var that=$(this);
        var oid=that.data("oid");
        showIndex(oid);
    });
});