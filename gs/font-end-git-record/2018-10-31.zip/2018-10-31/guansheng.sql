
        -- phpMyAdmin SQL Dump
-- version 4.0.10.20
-- https://www.phpmyadmin.net
--
-- 主机: 127.0.0.1
-- 生成日期: 2018-09-03 15:04:07
-- 服务器版本: 5.5.54
-- PHP 版本: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `guansheng`
--

-- --------------------------------------------------------

--
-- 表的结构 `ex_auth`
--

CREATE TABLE IF NOT EXISTS `ex_auth` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(10) NOT NULL,
  `control` char(30) DEFAULT NULL,
  `way` char(30) DEFAULT NULL,
  `css` char(30) DEFAULT NULL,
  `pid` int(11) NOT NULL,
  `hide` int(1) NOT NULL,
  `sort` int(2) NOT NULL,
  `del` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=114 ;

--
-- 转存表中的数据 `ex_auth`
--

INSERT INTO `ex_auth` (`id`, `name`, `control`, `way`, `css`, `pid`, `hide`, `sort`, `del`) VALUES
(1, '管理员中心', 'administrator', '', 'fa-user', 0, 0, 1, 0),
(2, '会员管理', 'user', '', 'fa-users', 0, 0, 2, 0),
(3, '商品管理', 'goods', '', 'fa-dropbox', 0, 0, 5, 0),
(4, '订单管理', 'orders', '', 'fa-bars', 0, 0, 6, 0),
(6, '系统设置', 'setup', '', 'fa-gears', 0, 0, 99, 0),
(7, '统计信息', 'analyze', '', 'fa-bar-chart-o', 0, 0, 8, 0),
(8, '角色管理', 'administrator', 'role', '', 1, 0, 0, 0),
(9, '添加角色', 'administrator', 'add', '', 1, 1, 0, 0),
(10, '修改角色', 'administrator', 'edit', '', 1, 1, 0, 0),
(11, '删除角色', 'administrator', 'del', '', 1, 1, 0, 0),
(12, '管理员列表', 'administrator', 'index', '', 1, 0, 0, 0),
(13, '添加管理员', 'administrator', 'add_auth', '', 1, 1, 0, 0),
(14, '修改管理员', 'administrator', 'edit_auth', '', 1, 1, 0, 0),
(15, '删除管理员', 'administrator', 'del_auth', '', 1, 1, 0, 0),
(20, '会员列表', 'user', 'index', '', 2, 0, 0, 0),
(21, '添加会员', 'user', 'add', '', 2, 1, 0, 0),
(22, '修改会员', 'user', 'edit', '', 2, 1, 0, 0),
(23, '删除会员', 'user', 'del', '', 2, 1, 0, 0),
(24, '商品分类', 'goods', 'category', '', 3, 0, 1, 0),
(25, '添加商品分类', 'goods', 'add_category', '', 3, 1, 0, 0),
(26, '修改商品分类', 'goods', 'edit_category', '', 3, 1, 0, 0),
(27, '删除商品分类', 'goods', 'del_category', '', 3, 1, 0, 0),
(28, '商品列表', 'goods', 'index', '', 3, 0, 2, 0),
(29, '添加商品', 'goods', 'add', '', 3, 1, 0, 0),
(30, '修改商品', 'goods', 'edit', '', 3, 1, 0, 0),
(31, '删除商品', 'goods', 'del', '', 3, 1, 0, 0),
(40, '订单列表', 'orders', 'index', '', 4, 0, 0, 0),
(41, '添加订单', 'orders', 'add', '', 4, 1, 0, 0),
(42, '修改订单', 'orders', 'edit', '', 4, 1, 0, 0),
(43, '删除订单', 'orders', 'delete', '', 4, 1, 0, 0),
(49, '基础信息', 'setup', 'basic', '', 6, 0, 0, 0),
(50, '广告管理', 'setup', 'ad_index', '', 6, 0, 0, 0),
(51, '添加广告', 'setup', 'ad_add', '', 6, 1, 0, 0),
(52, '修改广告', 'setup', 'ad_edit', '', 6, 1, 0, 0),
(53, '删除广告', 'setup', 'ad_delete', '', 6, 1, 0, 0),
(54, '单页管理', 'setup', 'about_index', '', 6, 0, 0, 0),
(55, '添加单页', 'setup', 'about_add', '', 6, 1, 0, 0),
(56, '修改单页', 'setup', 'about_edit', '', 6, 1, 0, 0),
(57, '删除单页', 'setup', 'about_delete', '', 6, 1, 0, 0),
(58, '订单统计', 'analyze', 'order', '', 7, 0, 0, 0),
(80, '优惠券管理', 'goods', 'coupon', NULL, 3, 0, 6, 0),
(81, '添加优惠券', 'goods', 'add_integral', NULL, 3, 1, 0, 0),
(82, '修改优惠券', 'goods', 'edit_integral', NULL, 3, 1, 0, 0),
(83, '删除优惠券', 'goods', 'del_integral', NULL, 3, 1, 0, 0),
(87, '店铺管理', 'shop', NULL, 'fa-archive', 0, 0, 3, 0),
(88, '店铺列表', 'shop', 'index', NULL, 87, 0, 0, 0),
(89, '添加店铺', 'shop', 'add', NULL, 87, 0, 0, 0),
(90, '修改店铺', 'shop', 'edit', NULL, 87, 1, 0, 0),
(91, '注销店铺', 'shop', 'del', NULL, 87, 1, 0, 0),
(77, '留言管理', 'message', NULL, 'fa-comments', 0, 0, 10, 0),
(109, '留言列表', 'message', 'index', NULL, 77, 0, 0, 0),
(112, '修改医师', 'shop', 'edit_doctor', NULL, 87, 1, 0, 0),
(113, '删除医师', 'shop', 'del_doctor', NULL, 87, 1, 0, 0),
(98, '银行信息管理', 'setup', 'banks', '', 6, 0, 0, 0),
(107, '退款订单', 'orders', 'refund', NULL, 4, 0, 0, 0),
(100, '修改银行信息', 'setup', 'edit_bank', '', 6, 1, 0, 0),
(101, '新增银行信息', 'setup', 'add_bank', '', 6, 1, 0, 0),
(102, '商品销售统计', 'analyze', 'goods', '', 7, 0, 0, 0),
(110, '医师列表', 'shop', 'doctor', NULL, 87, 0, 0, 0),
(111, '添加医师', 'shop', 'add_doctor', NULL, 87, 1, 0, 0),
(105, '提现订单列表', 'orders', 'withdraw', '', 4, 0, 0, 0),
(106, '提现订单修改', 'orders', 'edit_withdraw', '', 4, 1, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `yld_admin`
--

CREATE TABLE IF NOT EXISTS `yld_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` text COMMENT '管理员角色',
  `cid` int(11) NOT NULL COMMENT '所属公司id',
  `cname` char(30) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL COMMENT '职位id',
  `pname` char(30) DEFAULT NULL,
  `did` int(11) DEFAULT NULL COMMENT '部门id',
  `dname` char(30) DEFAULT NULL,
  `status` int(1) NOT NULL,
  `lastonline` datetime DEFAULT NULL COMMENT '最后在线时间',
  `number` char(20) DEFAULT NULL COMMENT '编号',
  `name` char(20) NOT NULL COMMENT '姓名',
  `head` varchar(200) DEFAULT '/source/images/head.png',
  `sex` enum('男','女') DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `idCard` char(20) DEFAULT NULL,
  `phone` char(11) DEFAULT NULL,
  `telphone` char(15) DEFAULT NULL,
  `trumpet` char(10) DEFAULT NULL COMMENT '短号',
  `email` varchar(100) DEFAULT NULL,
  `QQ` char(12) DEFAULT NULL,
  `dir` int(2) NOT NULL COMMENT '人员状态',
  `workdate` date NOT NULL COMMENT '入职日期',
  `positivedt` date DEFAULT NULL COMMENT '转正日期',
  `departure` date DEFAULT NULL COMMENT '离职日期',
  `sid` int(11) DEFAULT NULL COMMENT '上级id',
  `sname` varchar(30) DEFAULT NULL COMMENT '上级姓名',
  `hide` smallint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `qianming` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='后台管理员表' AUTO_INCREMENT=102 ;

--
-- 转存表中的数据 `yld_admin`
--

INSERT INTO `yld_admin` (`id`, `username`, `password`, `role`, `cid`, `cname`, `pid`, `pname`, `did`, `dname`, `status`, `lastonline`, `number`, `name`, `head`, `sex`, `birthday`, `idCard`, `phone`, `telphone`, `trumpet`, `email`, `QQ`, `dir`, `workdate`, `positivedt`, `departure`, `sid`, `sname`, `hide`, `del`, `qianming`) VALUES
(1, 'admin', '14e1b600b1fd579f47433b88e8d85291', '', 1, '四川翼灵动软件开发有限公司', 16, '销售主管', 1, '销售部', 1, '2018-08-24 14:52:54', '55', '超级管理员', '/uploads/head/20180707/1530948256493743.png', '男', '2017-08-15', '510823199410034265', '15528229145', NULL, '5644', '895635200@qq.com', '269378066444', 2, '2017-08-15', '2017-10-20', NULL, 22, '管理员', 0, 0, '/uploads/qianming/20180707/1530952668703056.jpg'),
(75, '15828502853', '14e1b600b1fd579f47433b88e8d85291', '["12"]', 1, '四川翼灵动软件开发有限公司', 33, NULL, 13, '技术部', 1, '2018-06-13 17:38:35', '1111', '张', '/source/images/head.png', '男', '0000-00-00', '', '15828502853', NULL, '', '', '', 1, '2018-06-07', NULL, NULL, 1, NULL, 0, 1, ''),
(76, '1321862262', '14e1b600b1fd579f47433b88e8d85291', '["13"]', 1, '四川翼灵动软件开发有限公司', 32, NULL, 1, '销售部', 0, NULL, '12', '得', '/source/images/head.png', '男', NULL, NULL, '028-8557112', NULL, NULL, NULL, NULL, 1, '2018-05-29', NULL, NULL, 1, NULL, 0, 1, ''),
(77, '123321', '14e1b600b1fd579f47433b88e8d85291', '["12","13"]', 1, '四川翼灵动软件开发有限公司', 16, '销售主管', 1, '销售部', 1, '2018-06-15 18:41:58', '001', '任宁宁', '/source/images/head.png', '男', NULL, NULL, '028-8557107', NULL, NULL, NULL, NULL, 2, '2017-06-13', NULL, NULL, 77, NULL, 0, 1, ''),
(78, '张婧', '14e1b600b1fd579f47433b88e8d85291', '["15"]', 8, '成都华浩电气有限公司', NULL, NULL, 21, '行政部', 1, '2018-07-02 17:20:27', '1', '张婧', '/source/images/head.png', '女', NULL, NULL, '12345', NULL, NULL, NULL, NULL, 2, '2018-06-12', NULL, NULL, NULL, NULL, 0, 0, ''),
(79, '向XX', '14e1b600b1fd579f47433b88e8d85291', '["2"]', 12, '成都天天电气有限公司', 35, '总经理', 29, '行政部', 1, '2018-07-07 22:31:44', '32', '向XX', '/source/images/head.png', '女', NULL, NULL, '1212121221', NULL, NULL, NULL, NULL, 2, '2017-07-06', NULL, NULL, NULL, NULL, 0, 0, ''),
(80, 'asd', '14e1b600b1fd579f47433b88e8d85291', '["2"]', 1, '成都冠晟电气有限公司', 16, '销售主管', 1, '销售部', 1, '2018-07-31 20:11:16', '1256', '订单', '/source/images/head.png', '男', NULL, NULL, '13333333333', NULL, NULL, NULL, NULL, 2, '2018-07-18', NULL, NULL, NULL, NULL, 0, 1, ''),
(81, 'cyzn', '14e1b600b1fd579f47433b88e8d85291', '', 14, '四川川岳智能科技有限公司', NULL, NULL, 43, '总经理', 1, '2018-08-23 09:31:46', '002', '林波', '/uploads/head/20180723/1532313777392801.jpg', '男', '0000-00-00', '', '13408474187', NULL, '', '', '', 2, '2018-07-20', NULL, NULL, NULL, NULL, 0, 0, ''),
(82, 'cyzn1', '14e1b600b1fd579f47433b88e8d85291', '["22"]', 14, '四川川岳智能科技有限公司', NULL, NULL, 43, '总经理', 1, '2018-07-23 10:55:15', '10', '刘世辉', '/source/images/head.png', '男', NULL, NULL, '13880863651', NULL, NULL, NULL, NULL, 2, '2018-07-19', NULL, NULL, NULL, NULL, 0, 0, ''),
(83, 'cyzn2', '14e1b600b1fd579f47433b88e8d85291', '["18"]', 14, '四川川岳智能科技有限公司', NULL, NULL, 38, '行政部', 1, '2018-07-23 10:58:03', NULL, '行政', '/source/images/head.png', '女', NULL, NULL, '13333333333', NULL, NULL, NULL, NULL, 2, '2018-07-19', NULL, NULL, NULL, NULL, 0, 0, ''),
(84, 'cyzn3', '14e1b600b1fd579f47433b88e8d85291', '["19"]', 14, '四川川岳智能科技有限公司', NULL, NULL, 40, '生产技术部', 1, '2018-07-21 19:31:48', '3', '报价', '/source/images/head.png', '男', NULL, NULL, '028-8557107', NULL, NULL, NULL, NULL, 2, '2018-07-19', NULL, NULL, NULL, NULL, 0, 0, ''),
(85, '林总', '14e1b600b1fd579f47433b88e8d85291', '["2"]', 17, '四川川岳智能科技有限公司', 35, '总经理', 44, '总经理', 0, NULL, '11', '林波', '/source/images/head.png', '男', NULL, NULL, '11111111111', NULL, NULL, NULL, NULL, 2, '2018-07-24', NULL, NULL, NULL, NULL, 0, 0, ''),
(86, 'sccyzn', '14e1b600b1fd579f47433b88e8d85291', '["2"]', 17, '四川川岳智能科技有限公司', 35, '总经理', 44, '总经理', 1, '2018-07-26 17:28:46', '50', '林波', '/source/images/head.png', '男', NULL, NULL, '11111111111', NULL, NULL, NULL, NULL, 2, '2018-07-25', NULL, NULL, NULL, '1', 0, 1, ''),
(87, 'sccyzn01', '14e1b600b1fd579f47433b88e8d85291', '', 17, '四川川岳智能科技有限公司', NULL, NULL, 45, '行政部', 1, NULL, '22', '米师', '/source/images/head.png', '男', NULL, NULL, '2222222222', NULL, NULL, NULL, NULL, 2, '2018-07-18', NULL, NULL, NULL, NULL, 0, 0, ''),
(100, '赵晓强', '14e1b600b1fd579f47433b88e8d85291', '["34"]', 19, '四川云顶华晟科技有限公司', 39, '销售总监', 57, '销售部', 1, '2018-08-13 22:29:30', '6', '赵晓强', '/source/images/head.png', '男', NULL, NULL, '13213213243', NULL, NULL, NULL, NULL, 2, '2018-08-12', NULL, NULL, NULL, NULL, 0, 0, ''),
(99, '任宁宁', '14e1b600b1fd579f47433b88e8d85291', '["33"]', 19, '四川云顶华晟科技有限公司', 38, '质检部主管', 56, '质检部', 1, NULL, '5', '任宁宁', '/source/images/head.png', '男', NULL, NULL, '1212123123', NULL, NULL, NULL, NULL, 2, '2018-08-12', NULL, NULL, NULL, NULL, 0, 0, ''),
(98, '向秋菊', '14e1b600b1fd579f47433b88e8d85291', '["32"]', 19, '四川云顶华晟科技有限公司', 37, '生产主任', 55, '生产部', 1, '2018-08-13 22:32:17', '4', '向秋菊', '/source/images/head.png', '女', NULL, NULL, '12121323232', NULL, NULL, NULL, NULL, 2, '2018-08-12', NULL, NULL, NULL, NULL, 0, 0, ''),
(97, '赵华容', '14e1b600b1fd579f47433b88e8d85291', '["31"]', 19, '四川云顶华晟科技有限公司', 36, '采购部主管', 54, '采购部', 1, '2018-08-13 22:23:27', '3', '赵华容', '/source/images/head.png', '女', NULL, NULL, '15674534242', NULL, NULL, NULL, NULL, 2, '2018-08-12', NULL, NULL, NULL, NULL, 0, 0, ''),
(95, '吴倩', '14e1b600b1fd579f47433b88e8d85291', '["2"]', 19, '四川云顶华晟科技有限公司', 35, '总经理', 52, '总经理', 1, '2018-08-14 15:03:37', '1', '吴倩', '/uploads/head/20180813/1534168248973956.jpg', '女', '0000-00-00', '', '13212312131', NULL, '', '', '', 2, '2018-08-12', NULL, NULL, NULL, NULL, 0, 0, '/uploads/qianming/20180813/1534170406579402.jpg'),
(96, '张国举', '14e1b600b1fd579f47433b88e8d85291', '["30"]', 19, '四川云顶华晟科技有限公司', 13, '行政主管', 53, '行政部', 1, NULL, '2', '张国举', '/source/images/head.png', '男', NULL, NULL, '1212121212', NULL, NULL, NULL, NULL, 2, '2018-08-12', NULL, NULL, NULL, NULL, 0, 0, ''),
(101, '张婧', '14e1b600b1fd579f47433b88e8d85291', '["30"]', 19, '四川云顶华晟科技有限公司', 40, '文员', 53, '行政部', 1, NULL, '7', '张婧', '/source/images/head.png', '女', NULL, NULL, '32323234232', NULL, NULL, NULL, NULL, 2, '2018-08-12', NULL, NULL, 96, NULL, 0, 0, '');

-- --------------------------------------------------------

--
-- 表的结构 `yld_auth`
--

CREATE TABLE IF NOT EXISTS `yld_auth` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(10) NOT NULL,
  `control` char(30) DEFAULT NULL,
  `way` char(30) DEFAULT NULL,
  `pid` int(11) NOT NULL,
  `hide` int(1) NOT NULL,
  `sort` int(2) NOT NULL,
  `branch` int(1) NOT NULL COMMENT '分公司账号是否有权限   0没有   1有',
  `user` tinyint(1) DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `img` char(5) DEFAULT '61',
  `img2` char(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='菜单表' AUTO_INCREMENT=289 ;

--
-- 转存表中的数据 `yld_auth`
--

INSERT INTO `yld_auth` (`id`, `title`, `control`, `way`, `pid`, `hide`, `sort`, `branch`, `user`, `del`, `img`, `img2`) VALUES
(1, '基础信息', '', '', 0, 0, 7, 1, 1, 0, '2', NULL),
(2, '权限管理', 'auth', '', 0, 0, 1, 1, 0, 0, '3', NULL),
(3, '行政管理', 'administration', '', 0, 0, 3, 1, 1, 0, '11', NULL),
(4, '销售管理', 'sell', '', 0, 0, 1, 1, 0, 0, '4', NULL),
(5, '技术管理', 'technology', '', 0, 0, 2, 1, 0, 0, '5', NULL),
(6, '采购管理', 'stock', '', 0, 0, 4, 1, 1, 0, '7', NULL),
(7, '质检管理', 'quality', '', 0, 0, 5, 1, 1, 0, '8', NULL),
(8, '仓库管理', 'warehouse', '', 0, 0, 6, 1, 1, 0, '9', NULL),
(9, '供应商列表', 'basic', 'supplier', 1, 0, 0, 1, 1, 0, '3', '62'),
(10, '客户管理', 'basic', 'customer', 1, 0, 0, 1, 1, 0, '4', '68'),
(11, '机构管理', 'basic', 'company', 1, 0, 0, 1, 1, 0, '5', '77'),
(12, '产品管理', 'basic', 'project', 1, 0, 0, 1, 1, 0, '6', '80'),
(252, '过程检验', 'produce', 'liucheng', 243, 0, 0, 1, NULL, 0, '61', NULL),
(14, '人员管理', 'auth', 'personnel', 2, 0, 0, 1, 1, 0, '9', '82'),
(15, '菜单角色管理', 'auth', 'role', 2, 0, 0, 1, 1, 0, '10', '92'),
(238, '元器件管理', 'basic', 'mater', 1, 0, 0, 1, NULL, 0, '61', '92'),
(245, '元器件检查', 'stock', 'mater', 6, 0, 0, 1, NULL, 0, '61', NULL),
(240, '订单列表', 'sell', 'orders', 4, 0, 0, 1, NULL, 0, '61', NULL),
(241, '报价单', 'technology', 'quotation', 5, 0, 0, 1, NULL, 0, '61', NULL),
(242, '合同管理', 'sell', 'contract', 4, 0, 0, 1, NULL, 0, '61', NULL),
(243, '生产管理', 'produce', NULL, 0, 0, 3, 1, NULL, 0, '6', NULL),
(244, '生产计划', 'produce', 'plan', 243, 0, 0, 1, NULL, 0, '61', NULL),
(246, '元器件变更申请', 'stock', 'biangeng', 6, 0, 1, 1, NULL, 0, '61', NULL),
(247, '采购申请', 'stock', 'caigou', 6, 0, 2, 1, NULL, 0, '61', NULL),
(248, '进货检验记录', 'quality', 'qualitylog', 7, 0, 0, 1, NULL, 0, '61', NULL),
(249, '不合格品报告', 'quality', 'report', 7, 0, 0, 1, NULL, 0, '61', NULL),
(250, '领料单', 'produce', 'draw', 243, 0, 0, 1, NULL, 0, '61', NULL),
(251, '流程设置', 'auth', 'setting', 2, 0, 0, 1, NULL, 0, '61', NULL),
(253, '设备自校记录', 'quality', 'zxlog', 7, 0, 0, 1, NULL, 0, '61', NULL),
(254, '例行检验记录', 'quality', 'dyctlog', 7, 0, 0, 1, NULL, 0, '61', NULL),
(255, '确认检查记录', 'quality', 'dyctqueren', 7, 0, 0, 1, NULL, 0, '61', NULL),
(256, '设备管理', 'quality', 'shebei', 7, 1, 0, 1, NULL, 0, '61', NULL),
(257, '成品入库', 'warehouse', 'ruku', 8, 0, 0, 1, NULL, 0, '61', NULL),
(258, '个人中心', 'person', NULL, 0, 0, 0, 1, NULL, 0, '2', NULL),
(259, '待办事项', 'person', 'upcoming', 258, 0, 1, 1, NULL, 0, '61', NULL),
(260, '消息提醒', 'person', 'remind', 258, 0, 2, 1, NULL, 0, '61', NULL),
(261, '通知公告', 'person', 'infor', 258, 0, 3, 1, NULL, 0, '61', NULL),
(262, '不合格报告项', 'administration', 'failed', 3, 0, 0, 1, NULL, 0, '61', NULL),
(263, '成品出库', 'warehouse', 'chuku', 8, 0, 0, 1, NULL, 0, '61', NULL),
(264, '元器件入库', 'warehouse', 'clruku', 8, 0, 0, 1, NULL, 0, '61', NULL),
(265, '元器件出库', 'warehouse', 'clchuku', 8, 0, 0, 1, NULL, 0, '61', NULL),
(266, '内审检查表', 'administration', 'nsjc', 3, 0, 0, 1, NULL, 0, '61', NULL),
(267, '内部审核计划', 'administration', 'nbshjh', 3, 0, 0, 1, NULL, 0, '61', NULL),
(268, '内部审核总结报告', 'administration', 'nbshzj', 3, 0, 0, 1, NULL, 0, '61', NULL),
(269, '文件清单', 'administration', 'wjqd', 3, 0, 0, 1, NULL, 0, '61', NULL),
(270, '文件分发记录', 'administration', 'wjff', 3, 0, 0, 1, NULL, 0, '61', NULL),
(271, '文件修订申请单', 'administration', 'wjxdsq', 3, 0, 0, 1, NULL, 0, '61', NULL),
(272, '表单领用记录', 'administration', 'bdly', 3, 0, 0, 1, NULL, 0, '61', NULL),
(273, '出厂检验', 'quality', 'chuchang', 7, 0, 0, 1, NULL, 0, '61', NULL),
(274, '外来文件清单', 'administration', 'wlwj', 3, 0, 0, 1, NULL, 0, '61', NULL),
(275, '年度培训计划', 'administration', 'ndpxjh', 3, 0, 0, 1, NULL, 0, '61', NULL),
(276, '培训记录', 'administration', 'pxjl', 3, 0, 0, 1, NULL, 0, '61', NULL),
(277, '年度内审计划', 'administration', 'ndnsjh', 3, 0, 0, 1, NULL, 0, '61', NULL),
(278, '获证产品档案', 'administration', 'hzcp', 3, 0, 0, 1, NULL, 0, '61', NULL),
(279, '生产设备保养记录', 'technology', 'sbbyjl', 5, 0, 0, 1, NULL, 0, '61', NULL),
(280, '自制图纸记录', 'technology', 'zztz', 5, 0, 0, 1, NULL, 0, '61', NULL),
(281, '生产设备维修计划', 'technology', 'sbwxjh', 5, 0, 0, 1, NULL, 0, '61', NULL),
(282, '报损单', 'technology', 'bsd', 5, 0, 0, 1, NULL, 0, '61', NULL),
(283, '检验和试验设备台账', 'quality', 'sbtz', 7, 0, 0, 1, NULL, 0, '61', NULL),
(284, '设备运行检查记录', 'quality', 'sbyxjc', 7, 0, 0, 1, NULL, 0, '61', NULL),
(285, '标志发放记录', 'quality', 'bzffjl', 7, 0, 0, 1, NULL, 0, '61', NULL),
(286, '检测设备校准计划', 'quality', 'sbxzjh', 7, 0, 0, 1, NULL, 0, '61', NULL),
(287, '供应商管理', 'stock', 'gysgl', 6, 0, 0, 1, NULL, 0, '61', NULL),
(288, '顾客反馈处理', 'sell', 'fankui', 4, 0, 0, 1, NULL, 0, '61', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `yld_bdly`
--

CREATE TABLE IF NOT EXISTS `yld_bdly` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `bianzhi` varchar(200) DEFAULT NULL COMMENT '编制',
  `shenhe` varchar(200) DEFAULT NULL COMMENT '审核',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL COMMENT '公司id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_bdly_ch`
--

CREATE TABLE IF NOT EXISTS `yld_bdly_ch` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bid` int(11) DEFAULT NULL COMMENT '文件清单表id',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `banben` varchar(10) DEFAULT NULL COMMENT '版本',
  `name` varchar(50) DEFAULT NULL COMMENT '文件名称',
  `sum` smallint(6) DEFAULT NULL COMMENT '复印/领用份数',
  `uname` varchar(20) DEFAULT NULL COMMENT '领用人',
  `explain` varchar(50) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件清单副表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_bsd`
--

CREATE TABLE IF NOT EXISTS `yld_bsd` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `case` varchar(200) DEFAULT NULL COMMENT '编制',
  `dep` varchar(30) DEFAULT NULL COMMENT '部门',
  `dt` varchar(30) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_bsd_ch`
--

CREATE TABLE IF NOT EXISTS `yld_bsd_ch` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '文件清单表id',
  `name` varchar(50) DEFAULT NULL COMMENT '文件名称',
  `num` decimal(20,0) DEFAULT NULL COMMENT '来源',
  `price` decimal(20,2) DEFAULT NULL COMMENT '归档日期',
  `money` decimal(20,2) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL COMMENT '接受部门',
  `explain` varchar(200) DEFAULT NULL COMMENT '分发部门',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件清单副表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_bzffjl`
--

CREATE TABLE IF NOT EXISTS `yld_bzffjl` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `dt` varchar(20) DEFAULT NULL COMMENT '购买日期',
  `bformat` varchar(50) DEFAULT NULL COMMENT '标识规格',
  `sum` decimal(11,0) DEFAULT NULL COMMENT '购买数量',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  `format` varchar(50) DEFAULT NULL,
  `fname` varchar(30) DEFAULT NULL,
  `fnum` decimal(11,0) DEFAULT NULL,
  `fdt` varchar(20) DEFAULT NULL,
  `lname` varchar(20) DEFAULT NULL,
  `yonghu` varchar(30) DEFAULT NULL,
  `snum` decimal(11,0) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='标识发放记录' AUTO_INCREMENT=12 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_bzffjl_ch`
--

CREATE TABLE IF NOT EXISTS `yld_bzffjl_ch` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '文件清单表id',
  `format` varchar(50) DEFAULT NULL COMMENT '产品型号规格',
  `fname` varchar(10) DEFAULT NULL COMMENT '发放人',
  `fdt` varchar(20) DEFAULT NULL COMMENT '发放日期',
  `fnum` decimal(11,0) DEFAULT NULL COMMENT '发放数量',
  `lname` varchar(20) DEFAULT NULL COMMENT '领用人',
  `yonghu` varchar(100) DEFAULT NULL COMMENT '用户',
  `snum` decimal(11,0) DEFAULT NULL COMMENT '剩余数量',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件清单副表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_chuchang`
--

CREATE TABLE IF NOT EXISTS `yld_chuchang` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `oid` int(11) DEFAULT NULL,
  `number` varchar(30) NOT NULL COMMENT '文件编号',
  `name` varchar(30) NOT NULL COMMENT '产品名称',
  `format` varchar(30) NOT NULL COMMENT '型号规格',
  `num` decimal(11,0) DEFAULT NULL COMMENT '检验数量',
  `dt` date DEFAULT NULL COMMENT '检验日期',
  `pnumber` varchar(30) DEFAULT NULL COMMENT '产品编号',
  `sign` varchar(200) DEFAULT NULL COMMENT '检验员签名',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(20) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `jilu` varchar(300) DEFAULT NULL COMMENT '检验记录',
  `jielun` varchar(300) DEFAULT NULL COMMENT '检验结论',
  `type` tinyint(1) NOT NULL COMMENT '1 检验记录    2确认检验记录',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `explain` varchar(300) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `mid` smallint(6) NOT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='低压成套设备成品例行检验记录' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_chuku`
--

CREATE TABLE IF NOT EXISTS `yld_chuku` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL COMMENT '入库单名称',
  `number` varchar(30) DEFAULT NULL COMMENT '文件编号',
  `dt` varchar(30) DEFAULT NULL COMMENT '日期',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `oid` int(11) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_chuku_produce`
--

CREATE TABLE IF NOT EXISTS `yld_chuku_produce` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL COMMENT '名称',
  `format` varchar(30) DEFAULT NULL COMMENT '型号规格',
  `num` decimal(11,0) DEFAULT NULL,
  `supplier` varchar(30) DEFAULT NULL COMMENT '制造商/生产厂',
  `explain` varchar(50) DEFAULT NULL COMMENT '备注',
  `project` varchar(30) DEFAULT NULL COMMENT '工程/项目',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='出库单产品' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_clchuku`
--

CREATE TABLE IF NOT EXISTS `yld_clchuku` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL COMMENT '入库单名称',
  `number` varchar(30) DEFAULT NULL COMMENT '文件编号',
  `dt` varchar(30) DEFAULT NULL COMMENT '日期',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `oid` int(11) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_clchuku_produce`
--

CREATE TABLE IF NOT EXISTS `yld_clchuku_produce` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL COMMENT '名称',
  `format` varchar(30) DEFAULT NULL COMMENT '型号规格',
  `num` decimal(11,0) DEFAULT NULL,
  `supplier` varchar(30) DEFAULT NULL COMMENT '制造商/生产厂',
  `explain` varchar(50) DEFAULT NULL COMMENT '备注',
  `project` varchar(30) DEFAULT NULL COMMENT '工程/项目',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='出库单产品' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_clruku`
--

CREATE TABLE IF NOT EXISTS `yld_clruku` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL COMMENT '入库单名称',
  `number` varchar(30) DEFAULT NULL COMMENT '文件编号',
  `dt` varchar(30) DEFAULT NULL COMMENT '日期',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `oid` int(11) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_clruku_produce`
--

CREATE TABLE IF NOT EXISTS `yld_clruku_produce` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL COMMENT '名称',
  `format` varchar(30) DEFAULT NULL COMMENT '型号规格',
  `num` decimal(11,0) DEFAULT NULL,
  `supplier` varchar(30) DEFAULT NULL COMMENT '制造商/生产厂',
  `explain` varchar(50) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='入库单产品' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_company`
--

CREATE TABLE IF NOT EXISTS `yld_company` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(20) NOT NULL COMMENT '分公司名称',
  `number` char(20) NOT NULL COMMENT '公司编码',
  `phone` char(15) NOT NULL COMMENT '电话',
  `address` varchar(50) NOT NULL COMMENT '地址',
  `email` varchar(50) NOT NULL COMMENT '邮箱',
  `fax` char(15) NOT NULL COMMENT '传真',
  `explain` varchar(200) NOT NULL COMMENT '备注',
  `sort` int(5) NOT NULL COMMENT '排序',
  `logo` varchar(200) NOT NULL,
  `color` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='分公司' AUTO_INCREMENT=20 ;

--
-- 转存表中的数据 `yld_company`
--

INSERT INTO `yld_company` (`id`, `name`, `number`, `phone`, `address`, `email`, `fax`, `explain`, `sort`, `logo`, `color`) VALUES
(1, '成都冠晟电气有限公司', '', '028-83516863', '', '', '', '', 100, '', ''),
(17, '四川川岳智能科技有限公司', '', '', '', '', '', '', 0, '/source/images/logo.png', ''),
(19, '四川云顶华晟科技有限公司', '', '', '', '', '', '', 0, '/tmp/1534164739317428.jpg', '');

-- --------------------------------------------------------

--
-- 表的结构 `yld_contract`
--

CREATE TABLE IF NOT EXISTS `yld_contract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `optid` smallint(6) DEFAULT '0',
  `number` varchar(30) DEFAULT NULL COMMENT '合同编号',
  `name` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL COMMENT '操作时间',
  `optname` varchar(20) DEFAULT NULL COMMENT '操作人',
  `adddt` datetime DEFAULT NULL COMMENT '申请日期',
  `explain` varchar(500) DEFAULT NULL COMMENT '说明',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态',
  `oid` int(11) DEFAULT '0',
  `cname` varchar(30) DEFAULT NULL COMMENT '客户名称',
  `money` decimal(10,2) DEFAULT '0.00' COMMENT '合同金额',
  `startdt` date DEFAULT NULL COMMENT '生效日期',
  `enddt` date DEFAULT NULL COMMENT '截止日期',
  `content` text COMMENT '合同内容',
  `signdt` date DEFAULT NULL COMMENT '签约日期',
  `phone` varchar(20) DEFAULT NULL,
  `files` varchar(255) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='客户合同' AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `yld_contract`
--

INSERT INTO `yld_contract` (`id`, `optid`, `number`, `name`, `optdt`, `optname`, `adddt`, `explain`, `status`, `oid`, `cname`, `money`, `startdt`, `enddt`, `content`, `signdt`, `phone`, `files`, `del`, `cid`) VALUES
(1, 88, 'C2018073101', '龙州名都配电工程', '2018-07-31 23:24:53', '郑启勇', '2018-07-31 23:24:34', '', 3, 2, '龙州名都配电工程', '183996.00', '2018-07-31', '2018-08-22', NULL, NULL, 'XXX', '', 0, 18),
(2, 95, 'C2018081301', '2323', '2018-08-13 22:31:27', '吴倩', '2018-08-13 22:30:09', '', 3, 6, '21', '4555555.00', '2018-08-13', '2018-08-30', NULL, NULL, '028-99898989', '5', 0, 19);

-- --------------------------------------------------------

--
-- 表的结构 `yld_customer`
--

CREATE TABLE IF NOT EXISTS `yld_customer` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL COMMENT '顾客名称',
  `uid` smallint(6) DEFAULT NULL COMMENT '负责人id',
  `uname` varchar(10) DEFAULT NULL COMMENT '负责人姓名',
  `address` varchar(100) DEFAULT NULL COMMENT '地区',
  `goodstype` varchar(50) DEFAULT NULL COMMENT '供货商品类型',
  `dt` date DEFAULT NULL COMMENT '供货时间',
  `relevel` tinyint(2) DEFAULT NULL COMMENT '信誉等级',
  `phone` varchar(30) DEFAULT NULL,
  `explain` varchar(200) DEFAULT NULL,
  `optid` smallint(6) DEFAULT NULL,
  `optname` varchar(10) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='顾客档案' AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `yld_customer`
--

INSERT INTO `yld_customer` (`id`, `company`, `name`, `uid`, `uname`, `address`, `goodstype`, `dt`, `relevel`, `phone`, `explain`, `optid`, `optname`, `optdt`, `del`, `cid`) VALUES
(1, '成都市鑫科欣电气有限公司', '零零', 81, '林波', '温江', '低压成套设备', NULL, 0, '18912015542', '', NULL, NULL, NULL, 0, 14),
(2, '达州金徽机电设备有限公司', '郑启勇', 88, '郑启勇', '达州', '低压成套开关设备', NULL, 0, '888888888', '', NULL, NULL, NULL, 0, 18),
(3, '四川融亿达房地产有限公司', '吴建斌', 88, '郑启勇', '达州', '低压成套开关设备', NULL, 0, '686868686868', '', NULL, NULL, NULL, 0, 18),
(4, '四川云顶华晟科技有限公司', '向秋菊', 1, '超级管理员', '成都温江', '配电柜', NULL, 0, '028-85571077', '', NULL, NULL, NULL, 0, 1),
(5, '浩瀚电气', '安徽地', 100, '赵晓强', '电大', '高压柜', NULL, 0, '028-99898989', '', NULL, NULL, NULL, 0, 19);

-- --------------------------------------------------------

--
-- 表的结构 `yld_custract`
--

CREATE TABLE IF NOT EXISTS `yld_custract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` smallint(6) DEFAULT '0',
  `number` varchar(30) DEFAULT NULL COMMENT '合同编号',
  `hnumber` varchar(30) NOT NULL,
  `optdt` datetime DEFAULT NULL COMMENT '操作时间',
  `optname` varchar(20) DEFAULT NULL COMMENT '操作人',
  `applydt` date DEFAULT NULL COMMENT '申请日期',
  `num` smallint(5) NOT NULL,
  `explain` varchar(500) DEFAULT NULL COMMENT '说明',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态',
  `custid` int(11) DEFAULT '0',
  `custname` varchar(255) DEFAULT NULL COMMENT '客户名称',
  `linkman` varchar(20) DEFAULT NULL COMMENT '客户联系人',
  `money` decimal(10,2) DEFAULT '0.00' COMMENT '合同金额',
  `startdt` date DEFAULT NULL COMMENT '生效日期',
  `enddt` date DEFAULT NULL COMMENT '截止日期',
  `content` text COMMENT '合同内容',
  `saleid` smallint(6) DEFAULT '0' COMMENT '销售机会Id',
  `isturn` tinyint(1) DEFAULT '1' COMMENT '是否提交',
  `signdt` date DEFAULT NULL COMMENT '签约日期',
  `type` tinyint(1) DEFAULT '0' COMMENT '0收款合同，1付款合同',
  `ispay` tinyint(1) DEFAULT '0' COMMENT '0待,1已完成,2部分',
  `isover` tinyint(1) DEFAULT '0' COMMENT '是否已全部创建收付款单',
  `createname` varchar(20) DEFAULT NULL,
  `createid` smallint(6) DEFAULT '0',
  `unit` decimal(11,3) NOT NULL,
  `files` varchar(255) NOT NULL,
  `usname` varchar(10) DEFAULT NULL,
  `did` int(11) DEFAULT NULL,
  `dname` varchar(30) DEFAULT NULL,
  `comid` int(11) DEFAULT NULL,
  `comname` varchar(30) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='客户合同' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_delete_log`
--

CREATE TABLE IF NOT EXISTS `yld_delete_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `table` varchar(30) DEFAULT NULL COMMENT '表名',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(20) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `mid` int(11) DEFAULT NULL COMMENT '主id',
  `cause` varchar(200) DEFAULT NULL COMMENT '删除原因',
  `title` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_department`
--

CREATE TABLE IF NOT EXISTS `yld_department` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(15) NOT NULL COMMENT '部门名称',
  `number` char(30) NOT NULL COMMENT '部门编码',
  `pid` int(11) NOT NULL COMMENT '上级部门id',
  `phone` char(15) NOT NULL COMMENT '电话',
  `fax` char(15) NOT NULL,
  `explain` varchar(200) NOT NULL COMMENT '备注',
  `sort` int(5) NOT NULL COMMENT '排序',
  `principalid` int(11) NOT NULL COMMENT '负责人id',
  `principalname` varchar(30) NOT NULL COMMENT '负责人姓名',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='部门表' AUTO_INCREMENT=58 ;

--
-- 转存表中的数据 `yld_department`
--

INSERT INTO `yld_department` (`id`, `name`, `number`, `pid`, `phone`, `fax`, `explain`, `sort`, `principalid`, `principalname`) VALUES
(1, '销售部', '', 1, '', '', '', 2, 1, '超级管理员'),
(2, '行政部', '', 1, '', '', '', 5, 1, '超级管理员'),
(13, '技术部', '', 1, '', '', '', 0, 0, ''),
(57, '销售部', '', 19, '', '', '', 0, 0, ''),
(56, '质检部', '', 19, '', '', '', 0, 0, ''),
(55, '生产部', '', 19, '', '', '', 0, 0, ''),
(54, '采购部', '', 19, '', '', '', 0, 0, ''),
(53, '行政部', '', 19, '', '', '', 0, 0, ''),
(52, '总经理', '', 19, '', '', '', 0, 0, ''),
(45, '行政部', '', 17, '', '', '', 0, 0, ''),
(44, '总经理', '', 17, '', '', '', 0, 0, ''),
(33, '行政部', '', 13, '15828502853', '028-999999999', '', 0, 0, ''),
(34, '采购部', '', 13, '', '028-887998873', '', 0, 0, ''),
(35, '技术部', '', 13, '', '', '', 0, 0, ''),
(36, '质检部', '', 13, '', '', '', 0, 0, ''),
(37, '仓库', '', 13, '', '', '', 0, 0, ''),
(38, '行政部', '', 14, '', '', '', 0, 0, ''),
(39, '采购部', '', 14, '', '', '', 0, 0, ''),
(40, '生产技术部', '', 14, '', '', '', 0, 0, ''),
(41, '质检部', '', 14, '', '', '', 0, 0, ''),
(42, '仓库', '', 14, '', '', '', 0, 0, ''),
(43, '总经理', '', 14, '', '', '', 0, 0, '');

-- --------------------------------------------------------

--
-- 表的结构 `yld_draw`
--

CREATE TABLE IF NOT EXISTS `yld_draw` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `oid` int(11) DEFAULT NULL COMMENT '订单id',
  `number` varchar(20) DEFAULT NULL COMMENT '文件编号',
  `uid` int(11) DEFAULT NULL,
  `uname` varchar(30) DEFAULT NULL COMMENT '车间',
  `dname` varchar(30) DEFAULT NULL COMMENT '备注',
  `status` tinyint(1) NOT NULL COMMENT '状态',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(10) DEFAULT NULL,
  `optdt` date DEFAULT NULL,
  `dt` varchar(20) DEFAULT NULL COMMENT '领用时间',
  `del` tinyint(1) NOT NULL,
  `explain` varchar(300) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='生产计划主表' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `yld_draw`
--

INSERT INTO `yld_draw` (`id`, `oid`, `number`, `uid`, `uname`, `dname`, `status`, `optid`, `optname`, `optdt`, `dt`, `del`, `explain`, `cid`) VALUES
(1, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, NULL, 18);

-- --------------------------------------------------------

--
-- 表的结构 `yld_draw_mater`
--

CREATE TABLE IF NOT EXISTS `yld_draw_mater` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL COMMENT '产品名称',
  `num` decimal(11,0) DEFAULT NULL COMMENT '数量',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='生产计划副表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_dyjy`
--

CREATE TABLE IF NOT EXISTS `yld_dyjy` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `oid` int(11) DEFAULT NULL,
  `number` varchar(30) NOT NULL COMMENT '文件编号',
  `name` varchar(30) NOT NULL COMMENT '产品名称',
  `format` varchar(30) NOT NULL COMMENT '型号规格',
  `num` decimal(11,0) DEFAULT NULL COMMENT '检验数量',
  `dt` date DEFAULT NULL COMMENT '检验日期',
  `pnumber` varchar(30) DEFAULT NULL COMMENT '产品编号',
  `sign` varchar(200) DEFAULT NULL COMMENT '检验员签名',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(20) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `jilu` varchar(300) DEFAULT NULL COMMENT '检验记录',
  `jielun` varchar(300) DEFAULT NULL COMMENT '检验结论',
  `type` tinyint(1) NOT NULL COMMENT '1 检验记录    2确认检验记录',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `explain` varchar(300) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `mid` int(11) NOT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='低压成套设备成品例行检验记录' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_failed`
--

CREATE TABLE IF NOT EXISTS `yld_failed` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `number` varchar(30) DEFAULT NULL COMMENT '报告编号',
  `dname` varchar(30) DEFAULT NULL COMMENT '受审部门',
  `address` varchar(30) DEFAULT NULL COMMENT '审核地点',
  `dt` varchar(15) DEFAULT NULL COMMENT '审核时间',
  `miaoshu` varchar(200) DEFAULT NULL COMMENT '不合格事实描述',
  `tiaokuan` varchar(5) DEFAULT NULL COMMENT '不合格条款号',
  `chengdu` tinyint(1) DEFAULT NULL COMMENT '不合格程度',
  `uid` int(11) DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='行政部不合格报告项' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_fankui`
--

CREATE TABLE IF NOT EXISTS `yld_fankui` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `oid` int(11) DEFAULT NULL,
  `onumber` varchar(30) DEFAULT NULL COMMENT '采购单id',
  `number` varchar(30) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL COMMENT '不合格品名称规格',
  `fkdt` varchar(30) DEFAULT NULL COMMENT '来源',
  `cpname` varchar(30) DEFAULT NULL COMMENT '不合格数量',
  `optid` int(11) DEFAULT NULL COMMENT '操作人id',
  `optname` varchar(30) DEFAULT NULL COMMENT '操作人员',
  `optdt` datetime DEFAULT NULL COMMENT '操作时间',
  `content` varchar(200) DEFAULT NULL COMMENT '投诉内容',
  `cname` varchar(200) DEFAULT NULL COMMENT '接获人',
  `case` varchar(200) DEFAULT NULL COMMENT '原因分析',
  `cdep` varchar(200) DEFAULT NULL COMMENT '责任部门',
  `jiejue` varchar(200) DEFAULT NULL COMMENT '投诉最终解决处理方案',
  `jdep` varchar(200) DEFAULT NULL COMMENT '负责部门',
  `cuoshi` varchar(200) DEFAULT NULL COMMENT '纠正措施',
  `cstype` tinyint(1) NOT NULL COMMENT '是否需要采取纠正、预防、巩固措施',
  `csdep` varchar(200) DEFAULT NULL COMMENT '责任部门',
  `csname` varchar(200) DEFAULT NULL COMMENT '质量负责人',
  `yygz` varchar(200) DEFAULT NULL COMMENT '顾客意见和验证跟踪',
  `yyuser` varchar(200) DEFAULT NULL COMMENT '验证人员',
  `yydt` datetime DEFAULT NULL COMMENT '验证时间',
  `del` tinyint(1) NOT NULL,
  `cid` smallint(6) DEFAULT NULL,
  `jluser` varchar(200) DEFAULT NULL,
  `files` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='不合格品处理报告' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_file`
--

CREATE TABLE IF NOT EXISTS `yld_file` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(200) DEFAULT NULL COMMENT '文件名',
  `filetype` varchar(50) DEFAULT NULL COMMENT '文件类型',
  `fileext` varchar(20) DEFAULT NULL COMMENT '文件后缀',
  `filesize` int(11) DEFAULT NULL COMMENT '文件大小',
  `filesizecn` varchar(100) DEFAULT NULL COMMENT '文件大小',
  `filepath` varchar(100) DEFAULT NULL COMMENT '文件路径',
  `optid` int(11) DEFAULT NULL COMMENT '操作人id',
  `optname` char(10) DEFAULT NULL COMMENT '操作人姓名',
  `time` char(15) DEFAULT NULL COMMENT '上传时间',
  `ip` varchar(30) DEFAULT NULL COMMENT '上传ip',
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `yld_file`
--

INSERT INTO `yld_file` (`id`, `filename`, `filetype`, `fileext`, `filesize`, `filesizecn`, `filepath`, `optid`, `optname`, `time`, `ip`, `cid`) VALUES
(1, '9表位(1).pdf', 'application/pdf', 'pdf', 60427, '59.01 KB', '/uploads/file/180813/1534150592536610.pdf', 1, '超级管理员', '1534150592', '110.184.53.208', NULL),
(2, '配电板产品描述GBT7251.3-2017.doc', 'application/octet-stream', 'doc', 96256, '94.00 KB', '/uploads/file/180813/1534150755327491.doc', 1, '超级管理员', '1534150755', '110.184.53.208', NULL),
(3, '12表位(1).pdf', 'application/pdf', 'pdf', 60834, '59.41 KB', '/uploads/file/180813/1534169729129185.pdf', 100, '赵晓强', '1534169729', '110.184.53.208', NULL),
(4, '总图(1).pdf', 'application/pdf', 'pdf', 50866, '49.67 KB', '/uploads/file/180813/1534170422056932.pdf', 95, '吴倩', '1534170422', '110.184.53.208', NULL),
(5, '9表位(1).pdf', 'application/pdf', 'pdf', 60427, '59.01 KB', '/uploads/file/180813/1534170608286956.pdf', 100, '赵晓强', '1534170608', '110.184.53.208', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `yld_filesr`
--

CREATE TABLE IF NOT EXISTS `yld_filesr` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `file` int(11) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `authtype` tinyint(1) DEFAULT NULL COMMENT '1->所有人，2->公司内部，3->部门内部，4->仅自己',
  `authid` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_flow_bill`
--

CREATE TABLE IF NOT EXISTS `yld_flow_bill` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `number` char(30) DEFAULT NULL COMMENT '单号',
  `table` char(30) DEFAULT NULL COMMENT '表名',
  `tid` int(11) DEFAULT NULL COMMENT '主id',
  `modelid` int(11) DEFAULT NULL COMMENT '模块id',
  `modelname` char(30) DEFAULT NULL COMMENT '模块名称',
  `cid` int(11) DEFAULT NULL,
  `cname` varchar(30) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL COMMENT '申请人id',
  `uname` char(15) DEFAULT NULL COMMENT '申请人姓名',
  `udeptname` char(15) DEFAULT NULL COMMENT '部门',
  `optdt` datetime DEFAULT NULL COMMENT '操作时间',
  `optid` int(11) DEFAULT NULL COMMENT '操作人id',
  `optname` char(15) DEFAULT NULL COMMENT '操作人姓名',
  `allcheckid` varchar(300) DEFAULT NULL COMMENT '所有审核人',
  `addtime` datetime DEFAULT NULL COMMENT '添加时间',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `statustext` varchar(50) DEFAULT NULL COMMENT '当前状态',
  `nowcheckid` varchar(100) DEFAULT NULL COMMENT '当前审核人id',
  `nowcheckname` varchar(500) DEFAULT NULL COMMENT '当前审核人姓名',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `applydt` date DEFAULT NULL,
  `checksm` varchar(500) DEFAULT NULL COMMENT '说明',
  `summary` varchar(200) DEFAULT NULL COMMENT '摘要',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='待办事项' AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `yld_flow_bill`
--

INSERT INTO `yld_flow_bill` (`id`, `number`, `table`, `tid`, `modelid`, `modelname`, `cid`, `cname`, `uid`, `uname`, `udeptname`, `optdt`, `optid`, `optname`, `allcheckid`, `addtime`, `status`, `statustext`, `nowcheckid`, `nowcheckname`, `del`, `applydt`, `checksm`, `summary`) VALUES
(2, 'QR-61', 'quotation', 2, 2, '报价单', 0, '', 91, '吴建斌', NULL, '2018-07-31 23:13:04', 88, '郑启勇', ',88,', '2018-07-31 23:03:45', 3, '审核通过', '0', '', 0, '2018-07-31', '', '【龙州名都配电工程】报价单'),
(3, 'C2018073101', 'contract', 1, 3, '合同', 0, '', 88, '郑启勇', NULL, '2018-07-31 23:24:53', 88, '郑启勇', ',88,', '2018-07-31 23:15:55', 3, '审核通过', '0', '', 0, '2018-07-31', '', '【龙州名都配电工程】合同'),
(4, '', 'produce', 1, 4, '生产计划', 0, '', 91, '吴建斌', NULL, '2018-08-01 10:19:20', 91, '吴建斌', ',91,', '2018-07-31 23:26:36', 3, '审核通过', '0', '', 0, '2018-07-31', '', '【】生产计划'),
(5, 'QR-45', 'quotation', 3, 2, '报价单', 1, '报价单审核', 91, '吴建斌', NULL, '2018-08-01 12:16:22', NULL, NULL, ',', '2018-08-01 12:16:22', 1, '待审核', ',88,', '郑启勇', 0, '2018-08-01', NULL, '【XXX】报价单'),
(6, '12', 'quotation', 6, 2, '报价单', 0, '', 98, '向秋菊', NULL, '2018-08-13 22:27:04', 95, '吴倩', ',95,', '2018-08-13 22:20:40', 3, '审核通过', '0', '', 0, '2018-08-13', '', '【21】报价单'),
(7, 'C2018081301', 'contract', 2, 3, '合同', 0, '', 100, '赵晓强', NULL, '2018-08-13 22:31:27', 95, '吴倩', ',95,', '2018-08-13 22:30:09', 3, '审核通过', '0', '', 0, '2018-08-13', '', '【2323】合同');

-- --------------------------------------------------------

--
-- 表的结构 `yld_flow_course`
--

CREATE TABLE IF NOT EXISTS `yld_flow_course` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL COMMENT '流程id',
  `pid` int(11) DEFAULT NULL COMMENT '上级id',
  `nid` int(11) DEFAULT NULL COMMENT '下级id',
  `name` varchar(20) DEFAULT NULL COMMENT '步骤名称',
  `checktype` varchar(20) DEFAULT NULL COMMENT '审核对象',
  `checktypeid` int(11) DEFAULT NULL COMMENT '审核对象id',
  `checktypename` varchar(50) DEFAULT NULL COMMENT '审核对象名称',
  `courseact` varchar(100) DEFAULT NULL COMMENT '审核动作',
  `opttime` char(11) DEFAULT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(20) DEFAULT NULL,
  `qianming` varchar(200) DEFAULT NULL,
  `files` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=77 ;

--
-- 转存表中的数据 `yld_flow_course`
--

INSERT INTO `yld_flow_course` (`id`, `sid`, `pid`, `nid`, `name`, `checktype`, `checktypeid`, `checktypename`, `courseact`, `opttime`, `optid`, `optname`, `qianming`, `files`) VALUES
(1, 2, 0, NULL, '报价单审核', 'admin', 95, '吴倩', '审核通过|3|green,驳回|2|red', '1534170283', 95, '吴倩', NULL, NULL),
(2, 3, 0, NULL, '合同审核', 'admin', 95, '吴倩', '审核通过|3|green,驳回|2|red', '1534170551', 95, '吴倩', NULL, NULL),
(13, 4, 0, NULL, '生产计划审核', 'admin', 91, '吴建斌', '审核通过|3|green,驳回|2|red', '1533050722', 88, '郑启勇', NULL, NULL),
(9, 6, 0, NULL, '元器件变更审核', 'admin', 91, '吴建斌', '审核通过|3|green,驳回|2|red', '1533050266', 88, '郑启勇', NULL, NULL),
(56, 7, 0, NULL, '采购单审核', 'pub', 0, '', '', '1533050340', 88, '郑启勇', NULL, NULL),
(46, 7, 56, NULL, '采购员采购', 'admin', 90, '陈容', '已采购|4|green', '1533050327', 88, '郑启勇', NULL, NULL),
(12, 8, 0, NULL, '检验合格', 'admin', 92, '谭显兵', '合格|3|green,更换合格|2|green', '1533050355', 88, '郑启勇', NULL, NULL),
(14, 9, 0, NULL, '主管审批', 'admin', 91, '吴建斌', '同意|3|green,驳回|2|red', '1533050396', 88, '郑启勇', NULL, NULL),
(15, 9, 14, NULL, '总经理审批', 'admin', 88, '郑启勇', '同意|4|green,驳回|1|red', '1533050403', 88, '郑启勇', NULL, NULL),
(58, 9, 15, NULL, '财务审批', 'admin', 88, '郑启勇', '同意|5|green,驳回|2|red', '1533050437', 88, '郑启勇', NULL, NULL),
(17, 9, 58, NULL, '领用人领取', 'admin', 91, '吴建斌', '已领取|6|green', '1533050446', 88, '郑启勇', NULL, NULL),
(18, 10, 0, NULL, '是否合格', 'admin', 93, '杜府国', '合格|3|green,整改合格|2|green', '1533050464', 88, '郑启勇', NULL, NULL),
(19, 11, 0, NULL, '是否通过', 'admin', 92, '谭显兵', '通过|3|green,不通过|2|red', '1533050485', 88, '郑启勇', NULL, NULL),
(20, 12, 0, NULL, '是否合格', 'admin', 1, '超级管理员', '合格|3|green,整改合格|2|green', '1520821477', 59, '王瀛', NULL, NULL),
(21, 13, 0, NULL, '是否合格', 'admin', 1, '超级管理员', '合格|3|green,整改合格|2|green', '1520821484', 59, '王瀛', NULL, NULL),
(62, 14, 0, NULL, '检验员检验', 'admin', 1, '超级管理员', '检验合格|3|green', NULL, NULL, NULL, NULL, NULL),
(63, 14, 62, NULL, '库管员确认', 'admin', 1, '超级管理员', '已入库|4|green', NULL, NULL, NULL, NULL, NULL),
(64, 16, 0, NULL, '负责人确认', 'admin', 1, '超级管理员', '确认不合格|3|green,检查有误|2|red', NULL, NULL, NULL, NULL, NULL),
(65, 16, 64, NULL, '原因分析', 'admin', 1, '超级管理员', '确定|4|green', NULL, NULL, NULL, NULL, NULL),
(66, 16, 65, NULL, '纠正措施', 'admin', 1, '超级管理员', '确定|5|green', NULL, NULL, NULL, NULL, NULL),
(67, 16, 66, NULL, '纠正措施验证', 'admin', 1, '超级管理员', '无效纠正|6|green,已纠正|7|green', NULL, NULL, NULL, NULL, NULL),
(68, 16, 67, NULL, '无效纠正措施的纠正在验证', 'admin', 1, '超级管理员', '已纠正|7|green', NULL, NULL, NULL, NULL, NULL),
(69, 17, 0, NULL, '领料员确认', 'admin', 1, '超级管理员', '已领料|3|green', NULL, NULL, NULL, NULL, NULL),
(70, 17, 69, NULL, '库管员确认', 'admin', 1, '超级管理员', '已出库|4|green', NULL, NULL, NULL, NULL, NULL),
(71, 18, 0, NULL, '检验员检验', 'admin', 1, '超级管理员', '检验合格|3|green', NULL, NULL, NULL, NULL, NULL),
(72, 18, 71, NULL, '库管员确认', 'admin', 1, '超级管理员', '已入库|4|green', NULL, NULL, NULL, NULL, NULL),
(73, 19, 0, NULL, '检验员检验', 'admin', 1, '超级管理员', '检验合格|3|green', NULL, NULL, NULL, NULL, NULL),
(74, 19, 73, NULL, '库管员确认', 'admin', 1, '超级管理员', '已出库|4|green', NULL, NULL, NULL, NULL, NULL),
(75, 27, 0, NULL, '是否通过', 'admin', 1, '超级管理员', '合格|3|green,整改合格|2|green', '1520821457', 59, '王瀛', '', ''),
(76, 5, 0, NULL, '采购部元器件检查', 'admin', 90, '陈容', '', '1533089374', 88, '郑启勇', NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `yld_flow_log`
--

CREATE TABLE IF NOT EXISTS `yld_flow_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table` varchar(50) DEFAULT NULL,
  `tid` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0' COMMENT '1通过',
  `statusname` varchar(20) DEFAULT NULL COMMENT '状态名称',
  `name` varchar(50) DEFAULT NULL COMMENT '进程名称',
  `courseid` int(11) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL COMMENT '操作时间',
  `explain` varchar(500) DEFAULT NULL COMMENT '说明',
  `ip` varchar(30) DEFAULT NULL,
  `checkname` varchar(20) DEFAULT NULL,
  `checkid` smallint(6) DEFAULT NULL,
  `mid` smallint(6) DEFAULT NULL COMMENT '@模块Id',
  `files` varchar(100) NOT NULL,
  `sign` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `table` (`table`,`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='单据操作记录' AUTO_INCREMENT=18 ;

--
-- 转存表中的数据 `yld_flow_log`
--

INSERT INTO `yld_flow_log` (`id`, `table`, `tid`, `status`, `statusname`, `name`, `courseid`, `optdt`, `explain`, `ip`, `checkname`, `checkid`, `mid`, `files`, `sign`) VALUES
(1, 'zxlog', 1, 1, '添加', '添加', 0, '2018-07-18 09:39:24', '', '222.209.70.51', '超级管理员', 1, 11, '', ''),
(2, 'quotation', 2, 1, '添加', '添加', 0, '2018-07-31 23:03:45', '', '110.184.51.39', '吴建斌', 91, 2, '', ''),
(3, 'quotation', 2, 1, '编辑', '编辑', 0, '2018-07-31 23:12:21', '', '110.184.51.39', '吴建斌', 91, 2, '', ''),
(4, 'quotation', 2, 3, '审核通过', '报价单审核', 1, '2018-07-31 23:13:04', '', '110.184.51.39', '郑启勇', 88, 2, '', ''),
(5, 'contract', 1, 1, '添加', '添加', 0, '2018-07-31 23:15:55', '', '110.184.51.39', '郑启勇', 88, 3, '', ''),
(6, 'contract', 1, 1, '编辑', '编辑', 0, '2018-07-31 23:24:34', '', '110.184.51.39', '郑启勇', 88, 3, '', ''),
(7, 'contract', 1, 3, '审核通过', '合同审核', 2, '2018-07-31 23:24:53', '', '110.184.51.39', '郑启勇', 88, 3, '', ''),
(8, 'produce', 1, 1, '添加', '添加', 0, '2018-07-31 23:26:36', '', '110.184.51.39', '吴建斌', 91, 4, '', ''),
(9, 'produce', 1, 3, '审核通过', '生产计划审核', 13, '2018-08-01 10:19:20', '', '110.184.51.39', '吴建斌', 91, 4, '', ''),
(10, 'purchase', 1, 1, '元器件检查', '全部存在', 0, '2018-08-01 10:24:09', '元器件全部在合格供应商名单中', '110.184.51.39', '陈容', 90, 5, '', ''),
(11, 'purchase', 1, 1, '元器件检查', '库存足够', 0, '2018-08-01 10:24:16', '元器件库存足够', '110.184.51.39', '陈容', 90, 5, '', ''),
(12, 'quotation', 3, 1, '添加', '添加', 0, '2018-08-01 12:16:22', '', '110.184.51.39', '吴建斌', 91, 2, '', ''),
(13, 'quotation', 6, 1, '添加', '添加', 0, '2018-08-13 22:20:40', '', '110.184.53.208', '向秋菊', 98, 2, '', ''),
(14, 'quotation', 6, 1, '编辑', '编辑', 0, '2018-08-13 22:25:34', '', '110.184.53.208', '向秋菊', 98, 2, '', ''),
(15, 'quotation', 6, 3, '审核通过', '报价单审核', 1, '2018-08-13 22:27:04', '', '110.184.53.208', '吴倩', 95, 2, '4', '/uploads/qianming/20180813/1534170406579402.jpg'),
(16, 'contract', 2, 1, '添加', '添加', 0, '2018-08-13 22:30:09', '', '110.184.53.208', '赵晓强', 100, 3, '', ''),
(17, 'contract', 2, 3, '审核通过', '合同审核', 2, '2018-08-13 22:31:27', '', '110.184.53.208', '吴倩', 95, 3, '', '');

-- --------------------------------------------------------

--
-- 表的结构 `yld_flow_set`
--

CREATE TABLE IF NOT EXISTS `yld_flow_set` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL COMMENT '流程名称',
  `table` varchar(30) DEFAULT NULL COMMENT '对应表',
  `type` tinyint(1) DEFAULT NULL COMMENT '流程类别',
  `statusstr` varchar(200) DEFAULT NULL COMMENT '状态值',
  `model` varchar(30) DEFAULT NULL,
  `sort` int(10) DEFAULT NULL,
  `hide` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- 转存表中的数据 `yld_flow_set`
--

INSERT INTO `yld_flow_set` (`id`, `name`, `table`, `type`, `statusstr`, `model`, `sort`, `hide`) VALUES
(1, '通知公告', 'infor', 1, NULL, 'Infor', 1, 0),
(2, '报价单', 'quotation', 2, '待报价|0|green', 'Quotation', 2, 0),
(3, '合同', 'contract', 2, '待上传|0|green', 'Contract', 3, 0),
(4, '生产计划', 'produce', 2, '待制作|0|green', 'Produce', 4, 0),
(5, '采购部元器件检查', 'purchase', 2, '', 'Purchase', 5, 1),
(6, '元器件变更', 'purchase_biangeng', 2, NULL, 'Purchase_biangeng', 6, 0),
(7, '采购申请', 'purchase_caigou', 2, '已采购|4|green', 'Purchase_caigou', 7, 0),
(8, '进货检验', 'qualitylog', 2, '待检验|0|green,更换合格|2|red,已检验|1|green,合格|3|green', 'Qualitylog', 8, 0),
(9, '物资领用申请', 'draw', 2, '待填报|0|green,待主管审批|1|green,驳回|2|red,待总经理审批|3|green,待财务审批|4|green,待领取|5|green,已领取|6|green', 'Draw', 9, 0),
(10, '生产过程流程卡', 'liucheng', 2, '待填报|0|green,整改合格|2|green,合格|3|green', 'Liucheng', 10, 0),
(11, '设备自校记录', 'zxlog', 2, NULL, 'Zxlog', 11, 0),
(12, '例行检验记录', 'dyjy', 2, '待填报|0|green,整改合格|2|green,合格|3|green', 'Dyjy', 12, 0),
(13, '确认检验记录', 'dyjy', 2, '待填报|0|green,整改合格|2|green,合格|3|green', 'Dyjyqr', 13, 0),
(14, '成品入库单', 'ruku', 2, '待填报|0|green,待检验|1|green,已检验|3|green,已入库|4|green', 'Ruku', 14, 0),
(15, '供应商审核', 'supplier', 1, '待填报|0|green,待检验|1|green,已检验|3|green,已入库|4|green', 'Supplier', 15, 0),
(16, '不合格项报告', 'failed', 1, '待确认|1|green,驳回|2|red,原因分析|3|green,待纠正|4|green,待验证|5|green,无效纠正|6|green,已纠正|7|green', 'Failed', 16, 0),
(17, '成品出库单', 'chuku', 1, '待填报|0|green,待领料|1|green,已领料|3|green,已出库|4|green', 'Chuku', 17, 0),
(18, '材料入库单', 'clruku', 1, '待填报|0|green,待检验|1|green,已检验|3|green,已入库|4|green', 'Clruku', 18, 0),
(19, '材料出库单', 'clchuku', 1, '待填报|0|green,待领料|1|green,已领料|3|green,已出库|4|green', 'Clchuku', 19, 0),
(20, '内审检查表', 'nsjc', 1, NULL, 'Nsjc', 20, 0),
(21, '内部审核计划', 'nbshjh', 1, NULL, 'Nbshjh', 21, 0),
(28, '供应商管理', 'gysgl', 3, NULL, 'Gysgl', NULL, 0),
(22, '内部审核总结报告', 'nbshzj', 1, NULL, 'Nbshzj', 22, 0),
(23, '文件清单', 'wjqd', 1, NULL, 'Wjqd', 23, 0),
(24, '文件分发记录', 'wjff', 1, NULL, 'Wjff', 24, 0),
(25, '文件修订申请单', 'wjxdsq', 1, NULL, 'Wjxdsq', 25, 0),
(26, '表单领用记录', 'bdly', 1, NULL, 'Bdly', NULL, 0),
(27, '出厂检验', 'chuchang', 1, '待填报|0|green,整改合格|2|green,合格|3|green', 'Chuchang', NULL, 0),
(29, '外来文件清单', 'wlwj', 1, NULL, 'Wlwj', NULL, 0),
(30, '年度培训计划', 'ndpxjh', 1, NULL, 'Ndpxjh', NULL, 0),
(31, '培训记录', 'pxjl', 1, NULL, 'Pxjl', NULL, 0),
(32, '年度内审计划', 'ndnsjh', 1, NULL, 'Ndnsjh', NULL, 0),
(33, '获证产品档案', 'hzcp', 1, NULL, 'Hzcp', NULL, 0),
(34, '生产设备保养记录', 'sbbyjl', 4, NULL, 'Sbbyjl', NULL, 0),
(35, '自制图纸记录', 'zztz', 4, NULL, 'Zztz', NULL, 0),
(36, '生产设备维修计划', 'sbwxjh', 4, NULL, 'Sbwxjh', NULL, 0),
(37, '报损单', 'bsd', 4, NULL, 'Bsd', NULL, 0),
(38, '检验和试验设备台账', 'sbtz', 5, NULL, 'Sbtz', NULL, 0),
(39, '设备运行检查记录', 'sbyxjc', 5, NULL, 'Sbyxjc', NULL, 0),
(40, '标志发放记录', 'bzffjl', 5, NULL, 'Bzffjl', NULL, 0),
(41, '检测设备校准计划', 'sbxzjh', 5, NULL, 'Sbxzjh', NULL, 0),
(42, '顾客反馈处理', 'fankui', 6, NULL, 'Fankui', NULL, 0);

-- --------------------------------------------------------

--
-- 表的结构 `yld_flow_todos`
--

CREATE TABLE IF NOT EXISTS `yld_flow_todos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `modelid` int(11) DEFAULT NULL,
  `modelname` varchar(30) DEFAULT NULL,
  `table` varchar(30) DEFAULT NULL,
  `tid` int(11) DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `adddt` datetime DEFAULT NULL,
  `readdt` datetime DEFAULT NULL,
  `isread` tinyint(1) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `senddt` varchar(15) NOT NULL,
  `type` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='通知对应人员' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_gysgl`
--

CREATE TABLE IF NOT EXISTS `yld_gysgl` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `name` varchar(50) DEFAULT NULL COMMENT '供货商名称',
  `produce` varchar(50) DEFAULT NULL COMMENT '主要供货产品',
  `zhiliang` varchar(200) DEFAULT NULL COMMENT '供货质量',
  `fuwu` varchar(200) DEFAULT NULL COMMENT '服务',
  `tousu` varchar(200) DEFAULT NULL COMMENT '投诉回复',
  `jiaohuo` varchar(200) DEFAULT NULL COMMENT '交货期',
  `jiage` varchar(200) DEFAULT NULL COMMENT '价格',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  `kaopin` varchar(500) DEFAULT NULL COMMENT '综合考评',
  `cg` varchar(200) DEFAULT NULL COMMENT '采购',
  `cgdt` varchar(100) DEFAULT NULL COMMENT '采购日期',
  `zl` varchar(200) DEFAULT NULL COMMENT '质量负责人',
  `zldt` varchar(100) DEFAULT NULL COMMENT '日期',
  `sum` varchar(10) DEFAULT NULL COMMENT '总计',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_hzcp`
--

CREATE TABLE IF NOT EXISTS `yld_hzcp` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `bianzhi` varchar(200) DEFAULT NULL COMMENT '编制',
  `jcbg` varchar(300) DEFAULT NULL COMMENT '工厂检查报告',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_hzcp_ch`
--

CREATE TABLE IF NOT EXISTS `yld_hzcp_ch` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '文件清单表id',
  `number` varchar(50) DEFAULT NULL COMMENT '证书编号',
  `name` varchar(50) DEFAULT NULL COMMENT '产品名称',
  `format` varchar(200) DEFAULT NULL COMMENT '生效日期',
  `fzdt` varchar(20) DEFAULT NULL COMMENT '发证日期',
  `zsenddt` varchar(20) DEFAULT NULL COMMENT '证书截止日期',
  `bgnumber` varchar(30) DEFAULT NULL COMMENT '报告编号',
  `bznumber` varchar(50) DEFAULT NULL COMMENT '标志印刷编号',
  `enddt` varchar(20) DEFAULT NULL COMMENT '截止日期',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件清单副表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_infor`
--

CREATE TABLE IF NOT EXISTS `yld_infor` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL COMMENT '标题',
  `type` char(10) DEFAULT NULL COMMENT '类型',
  `content` text COMMENT '内容',
  `recename` varchar(500) DEFAULT NULL,
  `receid` varchar(200) DEFAULT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `adddt` datetime DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `zuozhe` varchar(20) DEFAULT NULL COMMENT '来源',
  `status` tinyint(1) NOT NULL,
  `ty` tinyint(1) NOT NULL,
  `cid` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='通知公告' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_jyexamples`
--

CREATE TABLE IF NOT EXISTS `yld_jyexamples` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `q1` varchar(100) DEFAULT NULL,
  `w1` varchar(100) DEFAULT NULL,
  `e1` varchar(300) DEFAULT NULL,
  `q2` varchar(100) DEFAULT NULL,
  `w2` varchar(100) DEFAULT NULL,
  `e2` varchar(300) DEFAULT NULL,
  `q3` varchar(100) DEFAULT NULL,
  `w3` varchar(100) DEFAULT NULL,
  `e3` varchar(300) DEFAULT NULL,
  `q4` varchar(100) DEFAULT NULL,
  `w4` varchar(100) DEFAULT NULL,
  `e4` varchar(300) DEFAULT NULL,
  `q5` varchar(100) DEFAULT NULL,
  `w5` varchar(100) DEFAULT NULL,
  `e5` varchar(300) DEFAULT NULL,
  `q6` varchar(100) DEFAULT NULL,
  `w6` varchar(100) DEFAULT NULL,
  `e6` varchar(300) DEFAULT NULL,
  `q7` varchar(100) DEFAULT NULL,
  `w7` varchar(100) DEFAULT NULL,
  `e7` varchar(300) DEFAULT NULL,
  `q8` varchar(100) DEFAULT NULL,
  `w8` varchar(100) DEFAULT NULL,
  `e8` varchar(300) DEFAULT NULL,
  `q9` varchar(100) DEFAULT NULL,
  `w9` varchar(100) DEFAULT NULL,
  `e9` varchar(300) DEFAULT NULL,
  `q10` varchar(100) DEFAULT NULL,
  `w10` varchar(100) DEFAULT NULL,
  `e10` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `yld_jyexamples`
--

INSERT INTO `yld_jyexamples` (`id`, `type`, `name`, `q1`, `w1`, `e1`, `q2`, `w2`, `e2`, `q3`, `w3`, `e3`, `q4`, `w4`, `e4`, `q5`, `w5`, `e5`, `q6`, `w6`, `e6`, `q7`, `w7`, `e7`, `q8`, `w8`, `e8`, `q9`, `w9`, `e9`, `q10`, `w10`, `e10`) VALUES
(1, 1, '空白模板', '<textarea name="q1"></textarea>', '<textarea name="w1"></textarea>', '<textarea name="e1"></textarea>', '<textarea name="q2"></textarea>', '<textarea name="w2"></textarea>', '<textarea name="e2"></textarea>', '<textarea name="q3"></textarea>', '<textarea name="w3"></textarea>', '<textarea name="e3"></textarea>', '<textarea name="q4"></textarea>', '<textarea name="w4"></textarea>', '<textarea name="e4"></textarea>', '<textarea name="q5"></textarea>', '<textarea name="w5"></textarea>', '<textarea name="e5"></textarea>', '<textarea name="q6"></textarea>', '<textarea name="w6"></textarea>', '<textarea name="e6"></textarea>', '<textarea name="q7"></textarea>', '<textarea name="w7"></textarea>', '<textarea name="e7"></textarea>', '<textarea name="q8"></textarea>', '<textarea name="w8"></textarea>', '<textarea name="e8"></textarea>', '<textarea name="q9"></textarea>', '<textarea name="w9"></textarea>', '<textarea name="e9"></textarea>', '<textarea name="q10"></textarea>', '<textarea name="w10"></textarea>', '<textarea name="e10"></textarea>');

-- --------------------------------------------------------

--
-- 表的结构 `yld_lcex`
--

CREATE TABLE IF NOT EXISTS `yld_lcex` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `pid` int(11) NOT NULL,
  `sort` smallint(6) NOT NULL,
  `cid` int(11) NOT NULL,
  `sum` smallint(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `yld_lcex`
--

INSERT INTO `yld_lcex` (`id`, `name`, `pid`, `sort`, `cid`, `sum`) VALUES
(1, '电 气 装 配 工 序', 0, 0, 1, 0),
(2, '元器件安装', 1, 1, 0, 0),
(3, '一次线安装', 1, 2, 0, 0),
(4, '二次线安装', 1, 3, 0, 0),
(5, '电气间隙和爬电距离', 1, 4, 0, 0),
(6, '电气性能检查', 1, 5, 0, 0),
(7, '产品一致性检查', 1, 6, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `yld_lcex_ch`
--

CREATE TABLE IF NOT EXISTS `yld_lcex_ch` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `content` varchar(200) NOT NULL,
  `pid` int(11) NOT NULL,
  `sort` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- 转存表中的数据 `yld_lcex_ch`
--

INSERT INTO `yld_lcex_ch` (`id`, `content`, `pid`, `sort`) VALUES
(1, '箱(柜)体尺寸、结构与订单相符，外观无损', 2, 1),
(2, '元器件型号、规格与材料单相符，安装位置正确', 2, 2),
(3, '元件代号标识正确、齐全', 2, 3),
(4, '方便客户进出线', 2, 4),
(5, '机械操作灵活，多极开关同期性好，联锁可靠', 2, 5),
(6, '接地连续性的标识检查', 2, 6),
(7, '线径选择适当', 3, 1),
(8, '布线符合图纸及工艺要求', 3, 2),
(9, '相序排列正确，标识清楚', 3, 3),
(10, '紧固件松紧适度', 3, 4),
(11, '布线符合图纸及工艺要求', 4, 1),
(12, '线耳压接牢靠', 4, 2),
(13, '线号齐全，方向正确且与图纸一致', 4, 3),
(14, '紧固件松紧适度', 4, 4),
(15, '电气间隙符合标准要求≥10mm', 5, 1),
(16, '爬电距离符合标准要求≥12.5mm', 5, 2),
(17, '一次回路、二次回路能承受规定的工频耐压值', 6, 1),
(18, '必要时验证保护电路的电连续性', 6, 2),
(19, '测量回路、计量回路的仪表，指示准确且与主回', 6, 3),
(20, '控制回路各元件动作程序正确，指示对应', 6, 4),
(21, '电气联锁可靠', 6, 5),
(22, '具有保护功能的元件，其功能可靠', 6, 6),
(23, '产品结构是否与型式试验报告一致', 7, 1),
(24, '产品铭牌及标志、主要技术参数是否与型式试验报告一致', 7, 2),
(25, '主断路器/铜排/绝缘件是否与型式试验报告一致', 7, 3),
(26, '电流互感器是否与型式试验报告一致', 7, 4);

-- --------------------------------------------------------

--
-- 表的结构 `yld_liucheng`
--

CREATE TABLE IF NOT EXISTS `yld_liucheng` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `oid` int(11) DEFAULT NULL COMMENT '订单id',
  `number` varchar(30) DEFAULT NULL COMMENT '文件编号',
  `name` varchar(30) DEFAULT NULL COMMENT '产品名称',
  `format` varchar(30) DEFAULT NULL COMMENT '型号规格',
  `pnumber` varchar(30) DEFAULT NULL COMMENT '产品编号',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '状态',
  `cid` smallint(6) DEFAULT NULL,
  `lid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='生产过程检验流程卡' AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_liucheng_gongxu`
--

CREATE TABLE IF NOT EXISTS `yld_liucheng_gongxu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `type` tinyint(1) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL COMMENT '工序名称',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `sign` varchar(200) DEFAULT NULL,
  `dt` date DEFAULT NULL,
  `content` varchar(300) DEFAULT NULL,
  `sort` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='电气装配流程卡工序' AUTO_INCREMENT=19 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_login`
--

CREATE TABLE IF NOT EXISTS `yld_login` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(20) DEFAULT NULL,
  `ip` char(16) DEFAULT NULL,
  `time` datetime NOT NULL,
  `remark` char(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='登录记录' AUTO_INCREMENT=166 ;

--
-- 转存表中的数据 `yld_login`
--

INSERT INTO `yld_login` (`id`, `name`, `ip`, `time`, `remark`) VALUES
(1, '超级管理员', '110.184.241.184', '2018-07-17 18:04:48', '登录成功'),
(2, '超级管理员', '222.209.70.51', '2018-07-18 09:33:29', '登录成功'),
(3, '超级管理员', '110.184.51.13', '2018-07-19 11:01:12', '登录成功'),
(4, '林波', '110.184.51.13', '2018-07-19 11:11:07', '登录成功'),
(5, '林波', '110.184.51.13', '2018-07-19 11:12:26', '登录成功'),
(6, '超级管理员', '110.184.51.13', '2018-07-19 11:12:51', '登录成功'),
(7, '林波', '110.184.51.13', '2018-07-19 11:13:16', '登录成功'),
(8, '刘世辉', '110.184.51.13', '2018-07-19 11:20:21', '登录成功'),
(9, '行政', '110.184.51.13', '2018-07-19 11:20:39', '登录成功'),
(10, '林波', '110.184.51.13', '2018-07-19 11:21:10', '登录成功'),
(11, '报价', '110.184.51.13', '2018-07-19 11:22:29', '登录成功'),
(12, '刘世辉', '110.184.51.13', '2018-07-19 11:22:58', '登录成功'),
(13, '超级管理员', '110.184.241.75', '2018-07-19 11:28:12', '登录成功'),
(14, '超级管理员', '110.184.51.13', '2018-07-19 15:57:42', '登录成功'),
(15, '林波', '110.184.51.13', '2018-07-19 15:58:14', '登录成功'),
(16, '刘世辉', '110.184.51.13', '2018-07-19 15:59:14', '登录成功'),
(17, '刘世辉', '110.184.51.13', '2018-07-19 16:00:20', '登录失败：cyzn1'),
(18, '刘世辉', '110.184.51.13', '2018-07-19 16:00:26', '登录失败：cyzn1'),
(19, '刘世辉', '110.184.51.13', '2018-07-19 16:00:36', '登录成功'),
(20, '林波', '110.184.51.13', '2018-07-19 16:00:56', '登录成功'),
(21, '林波', '110.184.51.13', '2018-07-19 16:34:20', '登录成功'),
(22, '刘世辉', '110.184.51.13', '2018-07-19 16:36:04', '登录成功'),
(23, '林波', '110.184.51.13', '2018-07-19 16:37:17', '登录成功'),
(24, '林波', '110.184.241.75', '2018-07-19 16:38:38', '登录成功'),
(25, '超级管理员', '110.184.241.75', '2018-07-19 16:41:50', '登录成功'),
(26, '刘世辉', '110.184.51.13', '2018-07-19 16:53:44', '登录成功'),
(27, '超级管理员', '222.209.71.242', '2018-07-20 19:44:48', '登录成功'),
(28, '超级管理员', '117.136.62.81', '2018-07-21 19:22:58', '登录成功'),
(29, '林波', '117.136.62.81', '2018-07-21 19:23:21', '登录成功'),
(30, '行政', '117.136.62.81', '2018-07-21 19:30:03', '登录成功'),
(31, '刘世辉', '117.136.62.81', '2018-07-21 19:30:35', '登录成功'),
(32, '报价', '117.136.62.81', '2018-07-21 19:31:37', '登录成功'),
(33, '超级管理员', '117.136.62.99', '2018-07-22 09:23:14', '登录成功'),
(34, '林波', '117.136.62.99', '2018-07-22 09:25:19', '登录成功'),
(35, '超级管理员', '222.209.71.143', '2018-07-23 09:55:58', '登录成功'),
(36, '林波', '171.217.123.41', '2018-07-23 10:37:08', '登录成功'),
(37, '刘世辉', '171.217.123.41', '2018-07-23 10:55:13', '登录成功'),
(38, '林波', '171.217.123.41', '2018-07-23 10:55:49', '登录成功'),
(39, '林波', '171.217.123.41', '2018-07-23 10:57:28', '登录成功'),
(40, '行政', '171.217.123.41', '2018-07-23 10:58:02', '登录成功'),
(41, '林波', '171.217.123.41', '2018-07-23 10:58:18', '登录成功'),
(42, '超级管理员', '110.184.51.124', '2018-07-24 14:51:30', '登录成功'),
(43, '林波', '125.70.174.23', '2018-07-26 14:15:11', '登录成功'),
(44, '林波', '125.70.174.23', '2018-07-26 14:22:52', '登录成功'),
(45, '林波', '223.104.215.65', '2018-07-26 14:23:14', '登录成功'),
(46, '超级管理员', '223.104.215.65', '2018-07-26 14:23:31', '登录成功'),
(47, '林波', '125.70.174.23', '2018-07-26 14:23:39', '登录成功'),
(48, '林波', '125.70.174.23', '2018-07-26 14:24:26', '登录失败：cyzn'),
(49, '林波', '125.70.174.23', '2018-07-26 14:24:46', '登录失败：cyzn'),
(50, '林波', '125.70.174.23', '2018-07-26 14:26:58', '登录失败：cyzn'),
(51, '超级管理员', '223.104.215.65', '2018-07-26 14:27:18', '登录成功'),
(52, '林波', '110.184.48.71', '2018-07-26 16:58:52', '登录成功'),
(53, '超级管理员', '110.184.243.155', '2018-07-26 17:01:52', '登录成功'),
(54, '超级管理员', '110.184.48.71', '2018-07-26 17:02:03', '登录成功'),
(55, NULL, '110.184.48.71', '2018-07-26 17:19:32', '登录失败：林总'),
(56, '超级管理员', '110.184.48.71', '2018-07-26 17:19:49', '登录成功'),
(57, '林波', '110.184.48.71', '2018-07-26 17:22:15', '登录成功'),
(58, '林波', '110.184.48.71', '2018-07-26 17:24:39', '登录成功'),
(59, '超级管理员', '110.184.243.152', '2018-07-30 14:20:15', '登录成功'),
(60, '超级管理员', '110.184.243.152', '2018-07-30 14:20:35', '登录成功'),
(61, '超级管理员', '125.70.79.17', '2018-07-30 14:20:54', '登录成功'),
(62, '超级管理员', '110.184.243.152', '2018-07-30 14:22:43', '登录成功'),
(63, '超级管理员', '110.184.240.94', '2018-07-31 13:03:24', '登录成功'),
(64, '超级管理员', '223.104.216.77', '2018-07-31 13:06:51', '登录成功'),
(65, '超级管理员', '118.112.206.122', '2018-07-31 14:05:28', '登录成功'),
(66, '超级管理员', '118.112.206.122', '2018-07-31 14:12:14', '登录成功'),
(67, '超级管理员', '110.184.51.39', '2018-07-31 18:08:16', '登录成功'),
(68, '郑启勇', '110.184.51.39', '2018-07-31 19:49:02', '登录成功'),
(69, '超级管理员', '110.184.51.39', '2018-07-31 20:11:02', '登录成功'),
(70, '订单', '110.184.51.39', '2018-07-31 20:11:15', '登录成功'),
(71, '郑启勇', '110.184.51.39', '2018-07-31 20:14:34', '登录成功'),
(72, '杜府国', '110.184.51.39', '2018-07-31 20:28:16', '登录成功'),
(73, '郑启勇', '110.184.51.39', '2018-07-31 20:28:42', '登录成功'),
(74, '杜府国', '110.184.51.39', '2018-07-31 20:29:08', '登录成功'),
(75, NULL, '110.184.51.39', '2018-07-31 20:29:25', '登录失败：郑启勇'),
(76, '郑启勇', '110.184.51.39', '2018-07-31 20:29:34', '登录成功'),
(77, '吴建斌', '110.184.51.39', '2018-07-31 20:40:02', '登录成功'),
(78, '吴建斌', '110.184.51.39', '2018-07-31 21:49:15', '登录失败：吴建斌'),
(79, '吴建斌', '110.184.51.39', '2018-07-31 21:49:28', '登录成功'),
(80, '超级管理员', '110.184.51.39', '2018-07-31 22:54:58', '登录成功'),
(81, '吴建斌', '110.184.51.39', '2018-07-31 22:56:18', '登录成功'),
(82, '超级管理员', '110.184.51.39', '2018-07-31 23:04:15', '登录成功'),
(83, '郑启勇', '110.184.51.39', '2018-07-31 23:04:34', '登录成功'),
(84, '超级管理员', '110.184.51.39', '2018-07-31 23:05:01', '登录成功'),
(85, '吴建斌', '110.184.51.39', '2018-07-31 23:08:11', '登录成功'),
(86, '郑启勇', '110.184.51.39', '2018-07-31 23:08:59', '登录成功'),
(87, '超级管理员', '110.184.51.39', '2018-07-31 23:11:42', '登录成功'),
(88, '吴建斌', '110.184.51.39', '2018-07-31 23:12:11', '登录成功'),
(89, '郑启勇', '110.184.51.39', '2018-07-31 23:12:46', '登录成功'),
(90, '郑启勇', '110.184.51.39', '2018-07-31 23:14:04', '登录成功'),
(91, NULL, '110.184.51.39', '2018-07-31 23:14:23', '登录失败：郑启勇'),
(92, NULL, '110.184.51.39', '2018-07-31 23:14:36', '登录失败：郑启勇'),
(93, NULL, '110.184.51.39', '2018-07-31 23:14:47', '登录失败：郑启勇'),
(94, '吴建斌', '110.184.51.39', '2018-07-31 23:22:58', '登录成功'),
(95, '郑启勇', '110.184.51.39', '2018-07-31 23:24:04', '登录成功'),
(96, '超级管理员', '110.184.51.39', '2018-07-31 23:26:54', '登录成功'),
(97, '郑启勇', '110.184.51.39', '2018-07-31 23:27:17', '登录成功'),
(98, '陈容', '110.184.51.39', '2018-07-31 23:28:26', '登录成功'),
(99, '郑启勇', '110.184.51.39', '2018-08-01 09:17:23', '登录成功'),
(100, '超级管理员', '222.209.71.236', '2018-08-01 09:36:41', '登录成功'),
(101, '郑启勇', '110.184.51.39', '2018-08-01 09:37:51', '登录成功'),
(102, '超级管理员', '110.184.51.39', '2018-08-01 09:39:52', '登录成功'),
(103, '超级管理员', '110.184.51.39', '2018-08-01 09:40:16', '登录成功'),
(104, '郑启勇', '110.184.51.39', '2018-08-01 09:41:47', '登录成功'),
(105, '陈容', '110.184.51.39', '2018-08-01 10:09:45', '登录成功'),
(106, '郑启勇', '110.184.51.39', '2018-08-01 10:10:12', '登录成功'),
(107, '吴建斌', '110.184.51.39', '2018-08-01 10:10:48', '登录成功'),
(108, '郑启勇', '110.184.51.39', '2018-08-01 10:19:44', '登录成功'),
(109, '陈容', '110.184.51.39', '2018-08-01 10:20:18', '登录成功'),
(110, '吴建斌', '110.184.51.39', '2018-08-01 10:22:00', '登录成功'),
(111, '陈容', '110.184.51.39', '2018-08-01 10:23:13', '登录成功'),
(112, '郑启勇', '110.184.51.39', '2018-08-01 10:24:40', '登录成功'),
(113, '陈容', '110.184.51.39', '2018-08-01 10:25:13', '登录成功'),
(114, '郑启勇', '110.184.51.39', '2018-08-01 10:29:39', '登录成功'),
(115, '谭显兵', '110.184.51.39', '2018-08-01 10:30:18', '登录成功'),
(116, '郑启勇', '110.184.51.39', '2018-08-01 10:33:38', '登录成功'),
(117, '郑启勇', '110.184.51.39', '2018-08-01 10:35:42', '登录成功'),
(118, '郑启勇', '110.184.51.39', '2018-08-01 11:38:35', '登录成功'),
(119, '郑启勇', '110.184.51.39', '2018-08-01 12:12:56', '登录成功'),
(120, '吴建斌', '110.184.51.39', '2018-08-01 12:13:14', '登录成功'),
(121, '郑启勇', '110.184.51.39', '2018-08-01 12:13:55', '登录成功'),
(122, '吴建斌', '110.184.51.39', '2018-08-01 12:15:08', '登录成功'),
(123, '郑启勇', '110.184.51.39', '2018-08-01 12:16:44', '登录成功'),
(124, '郑启勇', '222.209.71.236', '2018-08-01 13:30:51', '登录成功'),
(125, '超级管理员', '110.184.51.39', '2018-08-02 14:51:27', '登录成功'),
(126, '郑启勇', '110.184.51.39', '2018-08-02 14:51:54', '登录成功'),
(127, '超级管理员', '110.184.51.39', '2018-08-02 14:52:43', '登录成功'),
(128, NULL, '110.184.51.39', '2018-08-03 09:16:18', '登录失败：cdsd'),
(129, '超级管理员', '110.184.51.39', '2018-08-03 09:16:28', '登录成功'),
(130, '超级管理员', '171.212.91.87', '2018-08-10 14:15:54', '登录成功'),
(131, '超级管理员', '110.184.53.208', '2018-08-13 16:54:29', '登录成功'),
(132, '超级管理员', '110.184.53.208', '2018-08-13 16:58:26', '登录成功'),
(133, '超级管理员', '110.184.53.208', '2018-08-13 20:48:59', '登录成功'),
(134, '超级管理员', '110.184.53.208', '2018-08-13 20:57:49', '登录成功'),
(135, NULL, '110.184.241.54', '2018-08-13 21:04:29', '登录失败：jw005'),
(136, '超级管理员', '110.184.241.54', '2018-08-13 21:04:36', '登录成功'),
(137, '超级管理员', '110.184.53.208', '2018-08-13 21:07:00', '登录成功'),
(138, '超级管理员', '182.149.189.143', '2018-08-13 21:23:53', '登录成功'),
(139, '超级管理员', '110.184.53.208', '2018-08-13 21:49:24', '登录成功'),
(140, '吴倩', '110.184.53.208', '2018-08-13 21:50:34', '登录成功'),
(141, '超级管理员', '182.149.189.143', '2018-08-13 22:00:16', '登录成功'),
(142, '赵晓强', '110.184.53.208', '2018-08-13 22:09:18', '登录成功'),
(143, '赵华容', '110.184.53.208', '2018-08-13 22:09:25', '登录成功'),
(144, '吴倩', '110.184.53.208', '2018-08-13 22:09:55', '登录成功'),
(145, '赵华容', '110.184.53.208', '2018-08-13 22:10:15', '登录成功'),
(146, '赵晓强', '110.184.53.208', '2018-08-13 22:10:59', '登录成功'),
(147, '吴倩', '110.184.53.208', '2018-08-13 22:11:18', '登录成功'),
(148, NULL, '110.184.53.208', '2018-08-13 22:11:36', '登录失败：向可菊'),
(149, '赵华容', '110.184.53.208', '2018-08-13 22:11:39', '登录成功'),
(150, '向秋菊', '110.184.53.208', '2018-08-13 22:11:55', '登录成功'),
(151, '赵晓强', '110.184.53.208', '2018-08-13 22:12:10', '登录成功'),
(152, '超级管理员', '110.184.53.208', '2018-08-13 22:21:06', '登录成功'),
(153, '吴倩', '110.184.53.208', '2018-08-13 22:21:53', '登录成功'),
(154, '超级管理员', '110.184.53.208', '2018-08-13 22:23:37', '登录成功'),
(155, '吴倩', '110.184.53.208', '2018-08-13 22:24:15', '登录成功'),
(156, '吴倩', '110.184.53.208', '2018-08-13 22:26:23', '登录成功'),
(157, '赵晓强', '110.184.53.208', '2018-08-13 22:28:05', '登录成功'),
(158, '吴倩', '110.184.53.208', '2018-08-13 22:28:37', '登录成功'),
(159, '赵晓强', '110.184.53.208', '2018-08-13 22:29:28', '登录成功'),
(160, '吴倩', '110.184.53.208', '2018-08-13 22:30:27', '登录成功'),
(161, '吴倩', '110.184.55.159', '2018-08-14 14:23:44', '登录成功'),
(162, '吴倩', '110.184.55.159', '2018-08-14 15:03:36', '登录成功'),
(163, '林波', '125.70.173.217', '2018-08-23 09:31:44', '登录成功'),
(164, '超级管理员', '125.70.173.217', '2018-08-23 09:32:35', '登录成功'),
(165, '超级管理员', '110.184.241.87', '2018-08-24 14:42:48', '登录成功');

-- --------------------------------------------------------

--
-- 表的结构 `yld_material`
--

CREATE TABLE IF NOT EXISTS `yld_material` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `number` char(30) NOT NULL COMMENT '编号',
  `name` varchar(50) NOT NULL COMMENT '名称',
  `format` char(30) DEFAULT NULL COMMENT '型号规格',
  `price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `unit` char(5) DEFAULT NULL COMMENT '单位',
  `sort` int(11) NOT NULL,
  `del` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`,`number`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2256 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_myoffice`
--

CREATE TABLE IF NOT EXISTS `yld_myoffice` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL COMMENT '名称',
  `type` varchar(30) DEFAULT NULL COMMENT '分类',
  `uid` int(11) DEFAULT NULL COMMENT '保管人id',
  `uname` char(15) DEFAULT NULL COMMENT '保管人姓名',
  `image` varchar(100) DEFAULT NULL COMMENT '图片',
  `explain` varchar(200) DEFAULT NULL COMMENT '说明',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `shopid` int(11) DEFAULT NULL,
  `udeptname` varchar(30) DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `status` varchar(30) NOT NULL,
  `applydt` datetime DEFAULT NULL,
  `model` varchar(30) DEFAULT NULL,
  `format` varchar(30) DEFAULT NULL,
  `price` decimal(11,2) DEFAULT NULL,
  `unit` char(5) DEFAULT NULL,
  `stock` decimal(11,0) NOT NULL,
  `money` int(11) NOT NULL COMMENT '押金',
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='印章' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_myofficeapl`
--

CREATE TABLE IF NOT EXISTS `yld_myofficeapl` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '申请人id',
  `uname` char(15) DEFAULT NULL COMMENT '申请人姓名',
  `applydt` datetime DEFAULT NULL COMMENT '申请时间',
  `explain` varchar(500) DEFAULT NULL COMMENT '说明',
  `gid` int(11) DEFAULT NULL COMMENT '印章id',
  `gname` varchar(50) DEFAULT NULL COMMENT '印章名称',
  `num` decimal(10,0) DEFAULT NULL COMMENT '是否外带',
  `money` int(11) NOT NULL COMMENT '押金',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `optid` int(11) DEFAULT NULL COMMENT '操作人id',
  `optname` varchar(30) DEFAULT NULL COMMENT '操作人姓名',
  `optdt` datetime DEFAULT NULL COMMENT '操作时间',
  `shopid` int(11) DEFAULT NULL,
  `udeptname` varchar(30) DEFAULT NULL,
  `files` varchar(300) DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `number` varchar(30) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_nbshjh`
--

CREATE TABLE IF NOT EXISTS `yld_nbshjh` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `type` enum('例行内部质量审核','临时内部质量审核') DEFAULT NULL COMMENT '审核性质',
  `mudi` varchar(200) DEFAULT NULL COMMENT '审核目的',
  `fanwei` varchar(200) DEFAULT NULL COMMENT '审核范围',
  `yiju` text COMMENT '审核依据',
  `zu` varchar(300) DEFAULT NULL COMMENT '审核组成员',
  `date` varchar(20) DEFAULT NULL COMMENT '审核日期',
  `anpai` text COMMENT '审核安排',
  `explain` varchar(200) DEFAULT NULL COMMENT '备注',
  `baogao` varchar(20) DEFAULT NULL COMMENT '审核报告分发时间',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL COMMENT '检查人',
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_nbshzj`
--

CREATE TABLE IF NOT EXISTS `yld_nbshzj` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `type` enum('例行内部质量审核','临时内部质量审核') DEFAULT NULL COMMENT '审核性质',
  `mudi` varchar(200) DEFAULT NULL COMMENT '审核目的',
  `fanwei` varchar(200) DEFAULT NULL COMMENT '审核范围',
  `yiju` text COMMENT '审核依据',
  `zu` varchar(300) DEFAULT NULL COMMENT '审核组成员',
  `date` varchar(20) DEFAULT NULL COMMENT '审核日期',
  `zongshu` text COMMENT '不合格项综述',
  `jielun` varchar(200) DEFAULT NULL COMMENT '审核结论',
  `baogao` varchar(300) DEFAULT NULL COMMENT '审核报告分发',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL COMMENT '检查人',
  `fujian` varchar(200) DEFAULT NULL COMMENT '附件情况',
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_ndnsjh`
--

CREATE TABLE IF NOT EXISTS `yld_ndnsjh` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL,
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `gl` varchar(100) DEFAULT NULL COMMENT '管理层',
  `xz` varchar(100) DEFAULT NULL COMMENT '行政部',
  `sc` varchar(100) DEFAULT NULL COMMENT '生产技术部',
  `cg` varchar(100) DEFAULT NULL COMMENT '采购部',
  `zj` varchar(100) DEFAULT NULL COMMENT '质检部',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL COMMENT '检查人',
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='年度内审计划' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_ndpxjh`
--

CREATE TABLE IF NOT EXISTS `yld_ndpxjh` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL,
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `date` varchar(20) DEFAULT NULL COMMENT '日期',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL COMMENT '检查人',
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='年度培训计划' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_ndpxjh_ch`
--

CREATE TABLE IF NOT EXISTS `yld_ndpxjh_ch` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '文件清单表id',
  `dep` varchar(30) DEFAULT NULL COMMENT '编号',
  `content` varchar(200) DEFAULT NULL COMMENT '版本',
  `duixiang` varchar(100) DEFAULT NULL COMMENT '文件名称',
  `type` enum('内训','外训') DEFAULT NULL COMMENT '生效日期',
  `month` varchar(100) DEFAULT NULL COMMENT '计划实施月份',
  `explain` varchar(50) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件清单副表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_nsjc`
--

CREATE TABLE IF NOT EXISTS `yld_nsjc` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `content` text COMMENT '检查情况',
  `jieguo` text COMMENT '判定',
  `zongjie` varchar(200) DEFAULT NULL COMMENT '总结',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL COMMENT '检查人',
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_office`
--

CREATE TABLE IF NOT EXISTS `yld_office` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL COMMENT '名称',
  `type` varchar(30) DEFAULT NULL COMMENT '分类',
  `uid` int(11) DEFAULT NULL COMMENT '保管人id',
  `uname` char(15) DEFAULT NULL COMMENT '保管人姓名',
  `image` varchar(100) DEFAULT NULL COMMENT '图片',
  `explain` varchar(200) DEFAULT NULL COMMENT '说明',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `shopid` int(11) DEFAULT NULL,
  `udeptname` varchar(30) DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `status` varchar(30) NOT NULL,
  `applydt` datetime DEFAULT NULL,
  `model` varchar(30) DEFAULT NULL,
  `format` varchar(30) DEFAULT NULL,
  `price` decimal(11,2) DEFAULT NULL,
  `unit` char(5) DEFAULT NULL,
  `stock` decimal(11,0) NOT NULL,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='印章' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_officeapl`
--

CREATE TABLE IF NOT EXISTS `yld_officeapl` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '申请人id',
  `uname` char(15) DEFAULT NULL COMMENT '申请人姓名',
  `applydt` datetime DEFAULT NULL COMMENT '申请时间',
  `explain` varchar(500) DEFAULT NULL COMMENT '说明',
  `gid` int(11) DEFAULT NULL COMMENT '印章id',
  `gname` varchar(50) DEFAULT NULL COMMENT '印章名称',
  `num` decimal(10,0) DEFAULT NULL COMMENT '是否外带',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `optid` int(11) DEFAULT NULL COMMENT '操作人id',
  `optname` varchar(30) DEFAULT NULL COMMENT '操作人姓名',
  `optdt` datetime DEFAULT NULL COMMENT '操作时间',
  `shopid` int(11) DEFAULT NULL,
  `udeptname` varchar(30) DEFAULT NULL,
  `files` varchar(300) DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `number` varchar(30) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_orders`
--

CREATE TABLE IF NOT EXISTS `yld_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `number` char(30) DEFAULT NULL COMMENT '订单编号',
  `name` varchar(30) DEFAULT NULL COMMENT '订单名称',
  `cid` int(11) DEFAULT NULL,
  `cname` varchar(10) DEFAULT NULL COMMENT '客户名称',
  `uid` int(11) DEFAULT NULL COMMENT '销售id',
  `uname` varchar(10) DEFAULT NULL COMMENT '销售名称',
  `adddt` datetime DEFAULT NULL COMMENT '下单时间',
  `status` tinyint(1) DEFAULT NULL COMMENT '订单状态',
  `explain` varchar(255) DEFAULT NULL COMMENT '备注',
  `files` varchar(200) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `money` decimal(11,2) DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` smallint(6) DEFAULT NULL,
  `optname` varchar(10) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `date` date DEFAULT NULL,
  `mid` smallint(6) NOT NULL,
  `comid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='订单表' AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `yld_orders`
--

INSERT INTO `yld_orders` (`id`, `number`, `name`, `cid`, `cname`, `uid`, `uname`, `adddt`, `status`, `explain`, `files`, `phone`, `address`, `money`, `del`, `optid`, `optname`, `optdt`, `date`, `mid`, `comid`) VALUES
(1, '2018072101', '低压柜制作', 1, '成都市鑫科欣电气有限', 81, '林波', '2018-07-21 19:29:34', 1, '', NULL, '18912015542', '温江', NULL, 0, 81, '林波', '2018-07-21 19:29:34', '2018-07-21', 0, 14),
(2, '2018073101', '龙州名都配电工程', 2, '达州金徽机电设备有限', 88, '郑启勇', '2018-07-31 20:37:06', 3, '', NULL, '888888888', '达州', '183996.00', 0, 90, '陈容', '2018-08-01 10:24:16', '2018-07-31', 6, 18),
(3, '2018073102', '西华家园10/0.4KV配电项目', 3, '四川融亿达房地产有限', 91, '吴建斌', '2018-07-31 20:40:34', 1, '', NULL, '686868686868', '达州', NULL, 0, 91, '吴建斌', '2018-07-31 20:40:34', '2018-07-31', 0, 18),
(4, '2018081301', '高压配电柜', 4, '四川云顶华晟科技有限', 1, '超级管理员', '2018-08-13 16:56:47', 1, '', '1', '028-85571077', '成都温江', NULL, 1, 1, '超级管理员', '2018-08-13 16:58:00', '2018-08-13', 0, 1),
(5, '2018081302', '高压配电柜', 4, '四川云顶华晟科技有限', 1, '超级管理员', '2018-08-13 16:59:16', 1, '', '2', '028-85571077', '成都温江', NULL, 0, 1, '超级管理员', '2018-08-13 16:59:16', '2018-08-13', 0, 1),
(6, '2018081303', '低压配电柜制造', 5, '浩瀚电气', 100, '赵晓强', '2018-08-13 22:15:42', 3, '', '3', '028-99898989', '电大', '0.00', 0, 95, '吴倩', '2018-08-13 22:31:27', '2018-08-13', 3, 19);

-- --------------------------------------------------------

--
-- 表的结构 `yld_paperwork`
--

CREATE TABLE IF NOT EXISTS `yld_paperwork` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL COMMENT '印章名称',
  `type` varchar(30) DEFAULT NULL COMMENT '印章类型',
  `uid` int(11) DEFAULT NULL COMMENT '保管人id',
  `uname` char(15) DEFAULT NULL COMMENT '保管人姓名',
  `image` varchar(100) DEFAULT NULL COMMENT '图片',
  `explain` varchar(200) DEFAULT NULL COMMENT '说明',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `shopid` int(11) DEFAULT NULL,
  `udeptname` varchar(30) DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `status` varchar(30) NOT NULL,
  `number` varchar(30) DEFAULT NULL,
  `applydt` datetime DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='印章' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_paperworkapl`
--

CREATE TABLE IF NOT EXISTS `yld_paperworkapl` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '申请人id',
  `uname` char(15) DEFAULT NULL COMMENT '申请人姓名',
  `applydt` datetime DEFAULT NULL COMMENT '申请时间',
  `explain` varchar(500) DEFAULT NULL COMMENT '说明',
  `gid` int(11) DEFAULT NULL COMMENT '印章id',
  `gname` varchar(50) DEFAULT NULL COMMENT '印章名称',
  `isout` tinyint(1) DEFAULT NULL COMMENT '是否外带',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `optid` int(11) DEFAULT NULL COMMENT '操作人id',
  `optname` varchar(30) DEFAULT NULL COMMENT '操作人姓名',
  `optdt` datetime DEFAULT NULL COMMENT '操作时间',
  `shopid` int(11) DEFAULT NULL,
  `udeptname` varchar(30) DEFAULT NULL,
  `files` varchar(300) DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `number` varchar(30) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_position`
--

CREATE TABLE IF NOT EXISTS `yld_position` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `number` char(15) DEFAULT NULL,
  `name` char(15) DEFAULT NULL COMMENT '职位名称',
  `departmentid` int(11) NOT NULL COMMENT '部门id',
  `remark` varchar(100) DEFAULT NULL,
  `sort` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='职位表' AUTO_INCREMENT=41 ;

--
-- 转存表中的数据 `yld_position`
--

INSERT INTO `yld_position` (`id`, `number`, `name`, `departmentid`, `remark`, `sort`) VALUES
(13, NULL, '行政主管', 0, NULL, 0),
(16, NULL, '销售主管', 0, NULL, 0),
(35, NULL, '总经理', 0, NULL, 0),
(36, NULL, '采购部主管', 0, NULL, 0),
(37, NULL, '生产主任', 0, NULL, 0),
(38, NULL, '质检部主管', 0, NULL, 0),
(39, NULL, '销售总监', 0, NULL, 0),
(40, NULL, '文员', 0, NULL, 0);

-- --------------------------------------------------------

--
-- 表的结构 `yld_produce`
--

CREATE TABLE IF NOT EXISTS `yld_produce` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `oid` int(11) DEFAULT NULL COMMENT '订单id',
  `number` varchar(20) DEFAULT NULL COMMENT '文件编号',
  `No` varchar(30) DEFAULT NULL,
  `workshop` varchar(30) DEFAULT NULL COMMENT '车间',
  `explain` varchar(300) DEFAULT NULL COMMENT '备注',
  `status` tinyint(1) NOT NULL COMMENT '状态',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(10) DEFAULT NULL,
  `optdt` date DEFAULT NULL,
  `checkdt` date DEFAULT NULL COMMENT '审核时间',
  `del` tinyint(1) NOT NULL,
  `cid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='生产计划主表' AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `yld_produce`
--

INSERT INTO `yld_produce` (`id`, `oid`, `number`, `No`, `workshop`, `explain`, `status`, `optid`, `optname`, `optdt`, `checkdt`, `del`, `cid`) VALUES
(1, 2, '', '', '', '', 3, 91, '吴建斌', '2018-08-01', NULL, 0, 18),
(2, 6, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, 19);

-- --------------------------------------------------------

--
-- 表的结构 `yld_produce_chanpin`
--

CREATE TABLE IF NOT EXISTS `yld_produce_chanpin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL COMMENT '产品名称',
  `format` varchar(30) DEFAULT NULL COMMENT '规格型号',
  `num` decimal(11,0) DEFAULT NULL COMMENT '数量',
  `dt` date DEFAULT NULL COMMENT '要求完成时间',
  `explain` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='生产计划副表' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `yld_produce_chanpin`
--

INSERT INTO `yld_produce_chanpin` (`id`, `pid`, `name`, `format`, `num`, `dt`, `explain`) VALUES
(1, 1, '120', '我', '1', '0000-00-00', '1');

-- --------------------------------------------------------

--
-- 表的结构 `yld_project`
--

CREATE TABLE IF NOT EXISTS `yld_project` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL COMMENT '产品名称',
  `format` varchar(30) DEFAULT NULL COMMENT '型号规格',
  `unit` varchar(5) DEFAULT NULL COMMENT '单位',
  `price` decimal(11,2) DEFAULT NULL COMMENT '成套价',
  `total` decimal(11,2) DEFAULT NULL COMMENT '合计',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `del` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='产品表' AUTO_INCREMENT=35 ;

--
-- 转存表中的数据 `yld_project`
--

INSERT INTO `yld_project` (`id`, `name`, `format`, `unit`, `price`, `total`, `number`, `del`) VALUES
(1, '高压进线柜', 'KYN28A-12', '台', '46353.00', NULL, NULL, 1),
(2, 'PT柜', 'KYN28A-12', '台', '46353.00', NULL, NULL, 1),
(3, 'PT柜', 'KYN28A-12', '台', '46353.00', NULL, NULL, 1),
(4, NULL, NULL, '台', '46353.00', NULL, NULL, 1),
(5, '刀开关', 'HD13BX-400/31 玻板', NULL, NULL, NULL, NULL, 1),
(6, '刀开关', 'HD13BX-600/31 玻板', NULL, NULL, NULL, NULL, 1),
(7, '塑壳断路器', 'NM1-63H/3300 25A', NULL, NULL, NULL, NULL, 1),
(8, '塑壳断路器', 'NM1-63H/3300 40A', NULL, NULL, NULL, NULL, 1),
(9, '塑壳断路器', 'NM1-125H/32002 63A', NULL, NULL, NULL, NULL, 1),
(10, '塑壳断路器', 'NM1-250H/32002 180A', '台', '46353.00', NULL, NULL, 1),
(11, '电流互感器', 'LMZJ1-0.5 25/5 一次穿芯', NULL, NULL, NULL, NULL, 1),
(12, '电流互感器', 'LMZJ1-0.5 50/5 一次穿心 3.0级', NULL, NULL, NULL, NULL, 1),
(13, '电流互感器', 'LMZJ1-0.5 75/5一次穿心  0.5级', NULL, NULL, NULL, NULL, 1),
(14, '电流互感器', 'LMZJ1-0.5 200/5 0.5级 一次穿心', NULL, NULL, NULL, NULL, 1),
(15, '电流互感器', 'LMZJ1-0.5 250/5 0.5级', NULL, NULL, NULL, NULL, 1),
(16, '电流表', '6L2-A 25/5', NULL, NULL, NULL, NULL, 1),
(17, '电流表', '6L2-A 50/5', NULL, NULL, NULL, NULL, 1),
(18, '电流表', '6L2-A 75/5', NULL, NULL, NULL, NULL, 1),
(19, '电流表', '6L2-A 200/5', NULL, NULL, NULL, NULL, 1),
(20, '电流表', '6L2-A 250/5', NULL, NULL, NULL, NULL, 1),
(21, '塑壳断路器', 'NM1-63H/3300 16A', NULL, NULL, NULL, NULL, 1),
(22, '塑壳断路器', 'NM1-63H/32002 16A', NULL, NULL, NULL, NULL, 1),
(23, '塑壳断路器', 'NM1-250H/3310 200A/分励电压 AC220V', NULL, NULL, NULL, NULL, 1),
(24, '主母线框', 'ZMJ1-100*10', NULL, NULL, NULL, NULL, 1),
(25, 'N母线框', 'LMJ-80*10', '台', '46353.00', NULL, NULL, 1),
(26, '主母排', 'TMY-100*8', NULL, NULL, NULL, NULL, 1),
(27, 'N排', 'TMY-80*8', NULL, NULL, NULL, NULL, 1),
(28, 'PE排', 'TMY-80*6', NULL, NULL, NULL, NULL, 1),
(29, '分母排', 'TMY-40*3', NULL, NULL, NULL, NULL, 1),
(30, '分母排', 'TMY-30*3', NULL, NULL, NULL, NULL, 1),
(31, '分支排', 'TMY-15*3', NULL, NULL, NULL, NULL, 1),
(32, '分支排', 'TMY-20*3', NULL, NULL, NULL, NULL, 1),
(33, '柜体', '1000*2200*600', NULL, NULL, NULL, NULL, 1),
(34, NULL, NULL, NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- 表的结构 `yld_pro_mater`
--

CREATE TABLE IF NOT EXISTS `yld_pro_mater` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '产品id',
  `number` varchar(15) DEFAULT NULL COMMENT '元器件编号',
  `name` varchar(15) DEFAULT NULL COMMENT '元器件名称',
  `format` varchar(30) DEFAULT NULL COMMENT '元器件规格',
  `unit` varchar(5) DEFAULT NULL COMMENT '单位',
  `price` decimal(11,2) DEFAULT NULL COMMENT '单价',
  `num` decimal(11,1) DEFAULT NULL COMMENT '数量',
  `money` decimal(11,2) DEFAULT NULL COMMENT '小计',
  `mid` int(11) DEFAULT NULL,
  `total` decimal(11,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='报价单产品元器件' AUTO_INCREMENT=96 ;

--
-- 转存表中的数据 `yld_pro_mater`
--

INSERT INTO `yld_pro_mater` (`id`, `pid`, `number`, `name`, `format`, `unit`, `price`, `num`, `money`, `mid`, `total`) VALUES
(1, 1, NULL, '高压断路器', 'VS1-12/630A/25KA', '台', '8000.00', '1.0', '8000.00', NULL, NULL),
(2, 1, NULL, '电流互感器', 'LZZBJ9-10  ', '台', '1150.00', '2.0', '2300.00', NULL, NULL),
(3, 1, NULL, '电压互感器', 'JDZ-10', '台', '1300.00', '2.0', '2600.00', NULL, NULL),
(4, 1, NULL, '综合保护装置', '', '台', '6000.00', '1.0', '6000.00', NULL, NULL),
(5, 1, NULL, '避雷器', 'HY5WS-17/50', '组', '210.00', '1.0', '210.00', NULL, NULL),
(6, 1, NULL, '过电压保护器', 'TBP-B-12.7/85-F-J', '组', '900.00', '1.0', '900.00', NULL, NULL),
(7, 1, NULL, '高压熔断器', 'XRNP-10/0.5A', '组', '210.00', '1.0', '210.00', NULL, NULL),
(8, 1, NULL, '带电显示器及传感器', 'GSN-10/T', '套', '250.00', '1.0', '250.00', NULL, NULL),
(9, 1, NULL, '机械连锁', '', '套', '1000.00', '1.0', '1000.00', NULL, NULL),
(10, 1, NULL, '柜内铜排', 'TMY-3(80×8)', 'kg', '82.00', '49.0', '4018.00', NULL, NULL),
(11, 1, NULL, '水平铜排', 'TMY-3(80×8)', 'kg', '82.00', '15.0', '1230.00', NULL, NULL),
(12, 1, NULL, '水平铜排PE', 'TMY-50×5', 'kg', '82.00', '2.0', '164.00', NULL, NULL),
(13, 1, NULL, '柜体', '800×1500×2300', '台', '9000.00', '1.0', '9000.00', NULL, NULL),
(14, 1, NULL, '辅助材料', '', '', '1200.00', '1.0', '1200.00', NULL, NULL),
(15, 2, NULL, '高压断路器', 'VS1-12/630A/25KA', '台', '8000.00', '1.0', '8000.00', NULL, NULL),
(16, 2, NULL, '电流互感器', 'LZZBJ9-10  ', '台', '1150.00', '2.0', '2300.00', NULL, NULL),
(17, 2, NULL, '电压互感器', 'JDZ-10', '台', '1300.00', '2.0', '2600.00', NULL, NULL),
(18, 2, NULL, '综合保护装置', '', '台', '6000.00', '1.0', '6000.00', NULL, NULL),
(19, 2, NULL, '避雷器', 'HY5WS-17/50', '组', '210.00', '1.0', '210.00', NULL, NULL),
(20, 2, NULL, '过电压保护器', 'TBP-B-12.7/85-F-J', '组', '900.00', '1.0', '900.00', NULL, NULL),
(21, 2, NULL, '高压熔断器', 'XRNP-10/0.5A', '组', '210.00', '1.0', '210.00', NULL, NULL),
(22, 2, NULL, '带电显示器及传感器', 'GSN-10/T', '套', '250.00', '1.0', '250.00', NULL, NULL),
(23, 2, NULL, '机械连锁', '', '套', '1000.00', '1.0', '1000.00', NULL, NULL),
(24, 2, NULL, '柜内铜排', 'TMY-3(80×8)', 'kg', '82.00', '49.0', '4018.00', NULL, NULL),
(25, 2, NULL, '水平铜排', 'TMY-3(80×8)', 'kg', '82.00', '15.0', '1230.00', NULL, NULL),
(26, 2, NULL, '水平铜排PE', 'TMY-50×5', 'kg', '82.00', '2.0', '164.00', NULL, NULL),
(27, 2, NULL, '柜体', '800×1500×2300', '台', '9000.00', '1.0', '9000.00', NULL, NULL),
(28, 2, NULL, '辅助材料', '', '', '1200.00', '1.0', '1200.00', NULL, NULL),
(29, 4, NULL, '刀开关', 'HD13BX-1500/31 玻板', '只', '1.00', '1.0', '1.00', NULL, NULL),
(30, 4, NULL, '万能框架断路器', 'NA1-2000X-1600M/3P电动固定AC380V', '只', '1.00', '1.0', '1.00', NULL, NULL),
(31, 4, NULL, '塑壳断路器', 'NM1-125H/3300 80A', '只', '1.00', '1.0', '1.00', NULL, NULL),
(32, 4, NULL, '浪涌保护器', 'NU6-Ⅱ 100kA/385V 4P', '只', '1.00', '1.0', '1.00', NULL, NULL),
(33, 4, NULL, '电流互感器', 'BH-0.66 100 1200/5 0.2S', '只', '3.00', '3.0', '9.00', NULL, NULL),
(34, 4, NULL, '电流互感器', 'BH-0.66 100 1200/5', '只', '1.00', '1.0', '1.00', NULL, NULL),
(35, 4, NULL, '电流互感器', 'BH-0.66 100 1500/5', '只', '3.00', '3.0', '9.00', NULL, NULL),
(36, 4, NULL, '电流表', '6L2-A 1500/5', '只', '3.00', '3.0', '9.00', NULL, NULL),
(37, 4, NULL, '电压表', '6L2-V 450V', '只', '1.00', '1.0', '1.00', NULL, NULL),
(38, 4, NULL, '转换开关', 'LW5-16 YH3/3   带螺丝手柄', '只', '1.00', '1.0', '1.00', NULL, NULL),
(39, 4, NULL, '电能表', '3×220V/380V 3*1.5(6A)', '台', '1.00', '1.0', '1.00', NULL, NULL),
(40, 4, NULL, '三相四线接线盒', 'DFY-3*4', '只', '1.00', '1.0', '1.00', NULL, NULL),
(41, 4, NULL, '电度表支架', '270型', '只', '2.00', '2.0', '4.00', NULL, NULL),
(42, 4, NULL, '熔断器', 'JF5-2.5RD/10A', '只', '5.00', '5.0', '25.00', NULL, NULL),
(43, 4, NULL, '指示灯', 'AD16-22D/S AC380V 黄色', '只', '1.00', '1.0', '1.00', NULL, NULL),
(44, 4, NULL, '指示灯', 'AD16-22D/S AC380V 绿色', '只', '1.00', '1.0', '1.00', NULL, NULL),
(45, 4, NULL, '指示灯', 'AD16-22D/S AC380V 红色', '只', '1.00', '1.0', '1.00', NULL, NULL),
(46, 4, NULL, '按钮开关', 'LA38-11黄色', '只', '1.00', '1.0', '1.00', NULL, NULL),
(47, 4, NULL, '按钮开关', 'LA38-11绿色', '只', '1.00', '1.0', '1.00', NULL, NULL),
(48, 4, NULL, '按钮开关', 'LA38-11红色', '只', '1.00', '1.0', '1.00', NULL, NULL),
(49, 4, NULL, '铜芯线', 'BV-16mm²', '米', '5.00', '5.0', '25.00', NULL, NULL),
(50, 4, NULL, '主母线框', 'ZMJ1-100*10', '只', '1.00', '1.0', '1.00', NULL, NULL),
(51, 4, NULL, 'N母线框', 'LMJ-80*10', '只', '1.00', '1.0', '1.00', NULL, NULL),
(52, 4, NULL, '主母排1', 'TMY-60*10', '米', '7.00', '7.0', '49.00', NULL, NULL),
(53, 4, NULL, '主母排2', 'TMY-100*8', '米', '8.00', '8.0', '64.00', NULL, NULL),
(54, 4, NULL, 'N排', 'TMY-80*8', '米', '1.00', '1.0', '1.00', NULL, NULL),
(55, 4, NULL, 'PE排', 'TMY-80*6', '米', '1.00', '1.0', '1.00', NULL, NULL),
(56, 4, NULL, '柜体', '1000*2200*600', '台', '1.00', '1.0', '1.00', NULL, NULL),
(57, 6, NULL, '电流表', '6L2-A 500/5', '台', '8000.00', '1.0', '8000.00', NULL, NULL),
(58, 6, NULL, '无功功率控制器', 'JKL5C-12 AC380V', '台', '1150.00', '2.0', '2300.00', NULL, NULL),
(59, 6, NULL, '小型断路器', 'TGB1N-63 3P D40', '台', '1300.00', '2.0', '2600.00', NULL, NULL),
(60, 6, NULL, '切换电容接触器', 'CJ19-43/11 380V', '台', '6000.00', '1.0', '6000.00', NULL, NULL),
(61, 6, NULL, '电力电容器', 'BSMJ0.4-20-3', '组', '210.00', '1.0', '210.00', NULL, NULL),
(62, 6, NULL, '避雷器', 'YH1.5W-0.28/1.3(只)', '组', '900.00', '1.0', '900.00', NULL, NULL),
(63, 6, NULL, '熔断器', 'JF5-2.5RD/10A', '组', '210.00', '1.0', '210.00', NULL, NULL),
(64, 6, NULL, '指示灯', 'AD16-22D/S AC380V 红色', '套', '250.00', '1.0', '250.00', NULL, NULL),
(65, 6, NULL, '铜芯线', 'BV-6mm²', '套', '1000.00', '1.0', '1000.00', NULL, NULL),
(66, 6, NULL, '主母线框', 'ZMJ1-100*10', 'kg', '82.00', '49.0', '4018.00', NULL, NULL),
(67, 6, NULL, 'N母线框', 'LMJ-80*10', 'kg', '82.00', '15.0', '1230.00', NULL, NULL),
(68, 6, NULL, '主母排', 'TMY-100*8', 'kg', '82.00', '2.0', '164.00', NULL, NULL),
(69, 34, NULL, '配电箱', 'XM总1', '台', '2848.93', '1.0', '2848.93', NULL, NULL),
(70, 34, NULL, '负荷隔离开关', 'HKKG2-250/4P 200A', '只', '397.00', '1.0', '397.00', NULL, NULL),
(71, 34, NULL, '塑壳断路器', 'HKKM1-225L/3300 140A', '只', '284.00', '1.0', '284.00', NULL, NULL),
(72, 34, NULL, '电气火灾监控单元', 'MXDF-K2/D160', '只', '450.00', '1.0', '450.00', NULL, NULL),
(73, 34, NULL, '塑壳断路器', 'HKKM1-100L/3300 80A', '只', '175.00', '2.0', '350.00', NULL, NULL),
(74, 34, NULL, '塑壳断路器', 'HKKM1-100L/3300 100A', '只', '175.00', '2.0', '350.00', NULL, NULL),
(75, 34, NULL, '小型漏电断路器', 'HKKC1L-63/1P+N 10A C型', '只', '46.00', '3.0', '138.00', NULL, NULL),
(76, 34, NULL, '小型断路器', 'HKKC1-63/4P 20A C型', '只', '53.00', '1.0', '53.00', NULL, NULL),
(77, 34, NULL, '浪涌保护器', 'NU6-II-40KA/4P', '只', '127.00', '1.0', '127.00', NULL, NULL),
(78, 34, NULL, '母排', '接地、接零排', '套', '30.00', '1.0', '30.00', NULL, NULL),
(79, 34, NULL, '辅材', '一、二次导线,线鼻等', '套', '120.00', '1.0', '120.00', NULL, NULL),
(80, 34, NULL, '箱体', '700*900*180', '台', '270.00', '1.0', '270.00', NULL, NULL),
(81, 34, NULL, '成套综合费', '含人工、管理、运输等费用', '台', '46353.00', '2.0', '92706.00', NULL, NULL),
(82, 34, NULL, '配电箱', 'XM总2', '台', '2848.93', '1.0', '2848.93', NULL, NULL),
(83, 34, NULL, '负荷隔离开关', 'HKKG2-250/4P 200A', '只', '397.00', '1.0', '397.00', NULL, NULL),
(84, 34, NULL, '塑壳断路器', 'HKKM1-225L/3300 140A', '只', '284.00', '1.0', '284.00', NULL, NULL),
(85, 34, NULL, '电气火灾监控单元', 'MXDF-K2/D160', '只', '450.00', '1.0', '450.00', NULL, NULL),
(86, 34, NULL, '塑壳断路器', 'HKKM1-100L/3300 80A', '只', '175.00', '2.0', '350.00', NULL, NULL),
(87, 34, NULL, '塑壳断路器', 'HKKM1-100L/3300 100A', '只', '175.00', '2.0', '350.00', NULL, NULL),
(88, 34, NULL, '小型漏电断路器', 'HKKC1L-63/1P+N 10A C型', '只', '46.00', '3.0', '138.00', NULL, NULL),
(89, 34, NULL, '小型断路器', 'HKKC1-63/4P 20A C型', '只', '53.00', '1.0', '53.00', NULL, NULL),
(90, 34, NULL, '浪涌保护器', 'NU6-II-40KA/4P', '只', '127.00', '1.0', '127.00', NULL, NULL),
(91, 34, NULL, '母排', '接地、接零排', '套', '30.00', '1.0', '30.00', NULL, NULL),
(92, 34, NULL, '辅材', '一、二次导线,线鼻等', '套', '120.00', '1.0', '120.00', NULL, NULL),
(93, 34, NULL, '箱体', '700*900*180', '台', '270.00', '1.0', '270.00', NULL, NULL),
(94, 34, NULL, '成套综合费', '含人工、管理、运输等费用', '套', '282.00', '1.0', '282.00', NULL, NULL),
(95, 34, NULL, '成套综合费', '含人工、管理、运输等费用', '套', '282.33', '1.0', '282.33', NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `yld_purchase`
--

CREATE TABLE IF NOT EXISTS `yld_purchase` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `oid` int(11) NOT NULL DEFAULT '0' COMMENT '订单id',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(10) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `is_have` tinyint(1) NOT NULL COMMENT '是否在合格供应商名单中',
  `is_stock` tinyint(1) NOT NULL COMMENT '库存是否充足',
  `del` tinyint(1) NOT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`,`oid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='采购部' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `yld_purchase`
--

INSERT INTO `yld_purchase` (`id`, `oid`, `optid`, `optname`, `optdt`, `is_have`, `is_stock`, `del`, `cid`) VALUES
(1, 2, 90, '陈容', '2018-08-01 10:24:16', 1, 1, 0, 18);

-- --------------------------------------------------------

--
-- 表的结构 `yld_purchase_biangeng`
--

CREATE TABLE IF NOT EXISTS `yld_purchase_biangeng` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `number` varchar(30) DEFAULT NULL COMMENT '文件编号',
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `dname` varchar(30) DEFAULT NULL COMMENT '部门',
  `project` varchar(30) DEFAULT NULL COMMENT '适用产品',
  `case` varchar(500) DEFAULT NULL COMMENT '变更原因',
  `start` varchar(500) DEFAULT NULL COMMENT '变更内容：变更前',
  `end` varchar(500) DEFAULT NULL COMMENT '变更内容：变更后',
  `yiju` varchar(300) DEFAULT NULL COMMENT '变更依据',
  `zlyijian` varchar(300) DEFAULT NULL COMMENT '质量负责人意见',
  `jsyijian` varchar(300) DEFAULT NULL COMMENT '技术负责人意见',
  `del` tinyint(1) NOT NULL,
  `oid` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `pid` int(11) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_purchase_caigou`
--

CREATE TABLE IF NOT EXISTS `yld_purchase_caigou` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `oid` int(11) DEFAULT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(10) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `number` varchar(30) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='采购申请' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_purchase_caigou_mater`
--

CREATE TABLE IF NOT EXISTS `yld_purchase_caigou_mater` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL COMMENT '名称',
  `format` varchar(50) DEFAULT NULL COMMENT '型号规格',
  `supplier` varchar(30) DEFAULT NULL COMMENT '供应商',
  `num` decimal(11,0) DEFAULT NULL COMMENT '数量',
  `explain` varchar(200) DEFAULT NULL COMMENT '备注',
  `yzjc` varchar(30) DEFAULT NULL COMMENT '验证检查',
  `wgjc` varchar(30) DEFAULT NULL COMMENT '外观检查',
  `ccjc` varchar(30) DEFAULT NULL COMMENT '尺寸检查',
  `xnjc` varchar(30) DEFAULT NULL COMMENT '性能检查',
  `jielun` varchar(30) DEFAULT NULL COMMENT '检验结论',
  `dt` varchar(30) DEFAULT NULL COMMENT '检验时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='采购单采购产品' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_purchase_mater`
--

CREATE TABLE IF NOT EXISTS `yld_purchase_mater` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '采购部申请id',
  `number` varchar(15) DEFAULT NULL COMMENT '元器件编号',
  `name` varchar(15) DEFAULT NULL COMMENT '元器件名称',
  `format` varchar(30) DEFAULT NULL COMMENT '元器件规格',
  `unit` varchar(5) DEFAULT NULL COMMENT '单位',
  `price` decimal(11,2) DEFAULT NULL COMMENT '单价',
  `num` decimal(11,1) DEFAULT NULL COMMENT '数量',
  `money` decimal(11,2) DEFAULT NULL COMMENT '小计',
  `mid` int(11) DEFAULT NULL,
  `total` decimal(11,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='报价单产品元器件' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `yld_purchase_mater`
--

INSERT INTO `yld_purchase_mater` (`id`, `pid`, `number`, `name`, `format`, `unit`, `price`, `num`, `money`, `mid`, `total`) VALUES
(1, 1, NULL, '主母排', 'TMY-100*8', 'kg', '82.00', '77.0', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `yld_pxjl`
--

CREATE TABLE IF NOT EXISTS `yld_pxjl` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `date` varchar(20) DEFAULT NULL COMMENT '培训日期',
  `lector` varchar(20) DEFAULT NULL COMMENT '讲师',
  `theme` varchar(50) DEFAULT NULL COMMENT '主题',
  `zongjie` varchar(200) DEFAULT NULL COMMENT '培训情况总结',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='培训记录' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_pxjl_ch`
--

CREATE TABLE IF NOT EXISTS `yld_pxjl_ch` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '文件清单表id',
  `name` varchar(10) DEFAULT NULL COMMENT '姓名',
  `dep` varchar(20) DEFAULT NULL COMMENT '部门',
  `diandao` varchar(100) DEFAULT NULL COMMENT '签到',
  `type` varchar(100) DEFAULT NULL COMMENT '考核方式',
  `result` varchar(20) DEFAULT NULL COMMENT '考核结果',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件清单副表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_qualitylog`
--

CREATE TABLE IF NOT EXISTS `yld_qualitylog` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `oid` int(11) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL COMMENT '采购单id',
  `optid` int(11) DEFAULT NULL COMMENT '进货人id',
  `optname` varchar(10) DEFAULT NULL COMMENT '采购人姓名',
  `optdt` datetime DEFAULT NULL COMMENT '采购时间',
  `status` tinyint(1) DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `number` varchar(30) DEFAULT NULL,
  `comid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='进货检验' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_quotation`
--

CREATE TABLE IF NOT EXISTS `yld_quotation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `number` varchar(20) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL COMMENT '项目名称',
  `contact` varchar(10) DEFAULT NULL COMMENT '联系人',
  `uid` int(11) DEFAULT NULL COMMENT '报价员id',
  `uname` varchar(10) DEFAULT NULL,
  `tel` varchar(15) DEFAULT NULL COMMENT '电话',
  `fax` varchar(15) DEFAULT NULL COMMENT '传真',
  `unumber` varchar(30) DEFAULT NULL COMMENT '编号',
  `date` varchar(20) DEFAULT NULL COMMENT '日期',
  `optid` int(11) DEFAULT NULL COMMENT '操作人id',
  `optname` varchar(10) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `del` tinyint(1) NOT NULL,
  `money` decimal(11,2) DEFAULT NULL,
  `oid` int(11) DEFAULT NULL COMMENT '订单id',
  `explain` varchar(300) DEFAULT NULL,
  `files` varchar(100) DEFAULT NULL,
  `pname` varchar(30) DEFAULT NULL,
  `title` varchar(30) NOT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='报价单' AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `yld_quotation`
--

INSERT INTO `yld_quotation` (`id`, `number`, `name`, `contact`, `uid`, `uname`, `tel`, `fax`, `unumber`, `date`, `optid`, `optname`, `optdt`, `status`, `del`, `money`, `oid`, `explain`, `files`, `pname`, `title`, `cid`) VALUES
(1, 'QR-61', 'XXX', 'XXX', 81, 'XXX', 'XXX', 'XXX', 'XXX', 'XXX', 81, '林波', '2018-07-23 10:44:32', 1, 0, '278118.00', 1, '1.本报价含税含联屏母线，含售后服务，不含运费，不含计量表；                                                                                                                                    2.有效期15天。', NULL, '高压开关柜', 'xxxx公司报价表', 14),
(2, 'QR-61', '龙州名都配电工程', '郑启勇', 91, '吴建斌', 'XXX', 'XXX', '6', '2018-07-31', 88, '郑启勇', '2018-07-31 23:13:04', 3, 0, '183996.00', 2, '1.本报价含税含联屏母线，含售后服务，不含运费，不含计量表；                                                                                                                                    2.有效期15天。', '', '高压开关柜', '', 18),
(3, 'QR-45', 'XXX', '任宁宁', 91, '吴建斌', '028-85571077', '028-85571077', '6', '2018-08-01', 91, '吴建斌', '2018-08-01 12:16:22', 1, 0, '0.00', 3, '1.本报价含税含联屏母线，含售后服务，不含运费，不含计量表；                                                                                                                                    2.有效期15天。', '', '高压开关柜', '', 18),
(4, NULL, NULL, '四川云顶华晟科技有限', NULL, NULL, '028-85571077', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 4, NULL, NULL, NULL, '', 1),
(5, NULL, NULL, '四川云顶华晟科技有限', NULL, NULL, '028-85571077', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 5, NULL, NULL, NULL, '', 1),
(6, '12', '21', '浩瀚电气', 98, '向秋菊', '028-99898989', '', '4', '2018-08-13', 95, '吴倩', '2018-08-13 22:27:04', 3, 0, '0.00', 6, '', '', '', '', 19);

-- --------------------------------------------------------

--
-- 表的结构 `yld_quo_project`
--

CREATE TABLE IF NOT EXISTS `yld_quo_project` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `qid` int(11) DEFAULT NULL COMMENT '报价单id',
  `pid` int(11) DEFAULT NULL COMMENT '产品id',
  `name` varchar(30) DEFAULT NULL COMMENT '产品名称',
  `format` varchar(30) DEFAULT NULL COMMENT '产品规格',
  `unit` varchar(5) DEFAULT NULL COMMENT '单位',
  `num` decimal(11,0) DEFAULT NULL COMMENT '数量',
  `money` decimal(11,2) DEFAULT NULL COMMENT '成套价',
  `price` decimal(11,2) DEFAULT NULL COMMENT '小计',
  `total` decimal(11,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='报价单产品表' AUTO_INCREMENT=43 ;

--
-- 转存表中的数据 `yld_quo_project`
--

INSERT INTO `yld_quo_project` (`id`, `qid`, `pid`, `name`, `format`, `unit`, `num`, `money`, `price`, `total`) VALUES
(1, 1, 1, '高压进线柜', 'KYN28A-12', '台', '2', '92706.00', '46353.00', NULL),
(2, 2, 1, 'PT柜', 'KYN28A-12', '台', '2', '92706.00', '46353.00', NULL),
(3, 3, 1, 'PT柜', 'KYN28A-12', '台', '2', '92706.00', '46353.00', NULL),
(4, 5, 2, '刀开关', 'HD13BX-400/31 玻板', NULL, '6', '204.00', '34.00', NULL),
(5, 6, 2, '刀开关', 'HD13BX-600/31 玻板', NULL, '5', '26725.00', '5345.00', NULL),
(6, 7, 2, '塑壳断路器', 'NM1-63H/3300 25A', NULL, '5', '27170.00', '5434.00', NULL),
(7, 8, 2, '塑壳断路器', 'NM1-63H/3300 40A', NULL, '6', '204.00', '34.00', NULL),
(8, 9, 2, '塑壳断路器', 'NM1-125H/32002 63A', NULL, '5', '170.00', '34.00', NULL),
(9, 10, 2, '塑壳断路器', 'NM1-250H/32002 180A', '台', '34', '1156.00', '34.00', NULL),
(10, 11, 2, '电流互感器', 'LMZJ1-0.5 25/5 一次穿芯', NULL, '34', '1156.00', '34.00', NULL),
(11, 12, 2, '电流互感器', 'LMZJ1-0.5 50/5 一次穿心 3.0级', NULL, '34', '1156.00', '34.00', NULL),
(12, 13, 2, '电流互感器', 'LMZJ1-0.5 75/5一次穿心  0.5级', NULL, '34', '1802.00', '53.00', NULL),
(13, 14, 2, '电流互感器', 'LMZJ1-0.5 200/5 0.5级 一次穿心', NULL, '34', '1530.00', '45.00', NULL),
(14, 15, 2, '电流互感器', 'LMZJ1-0.5 250/5 0.5级', NULL, '2', '92706.00', '46353.00', NULL),
(15, 16, 2, '电流表', '6L2-A 25/5', NULL, '34', '1836.00', '54.00', NULL),
(16, 17, 2, '电流表', '6L2-A 50/5', NULL, '34', '1530.00', '45.00', NULL),
(17, 18, 2, '电流表', '6L2-A 75/5', NULL, '56', '2520.00', '45.00', NULL),
(18, 19, 2, '电流表', '6L2-A 200/5', NULL, '435', '19575.00', '45.00', NULL),
(19, 20, 2, '电流表', '6L2-A 250/5', NULL, '34', '1530.00', '45.00', NULL),
(20, 21, 2, '塑壳断路器', 'NM1-63H/3300 16A', NULL, '34', '782.00', '23.00', NULL),
(21, 22, 2, '塑壳断路器', 'NM1-63H/32002 16A', NULL, '34', '782.00', '23.00', NULL),
(22, 23, 2, '塑壳断路器', 'NM1-250H/3310 200A/分励电压 AC220V', NULL, '34', '1462.00', '43.00', NULL),
(23, 24, 2, '主母线框', 'ZMJ1-100*10', NULL, '0', '0.00', '0.00', NULL),
(24, 25, 2, 'N母线框', 'LMJ-80*10', '台', '0', '0.00', '0.00', NULL),
(25, 26, 2, '主母排', 'TMY-100*8', NULL, '0', '0.00', '0.00', NULL),
(26, 27, 2, 'N排', 'TMY-80*8', NULL, '0', '0.00', '0.00', NULL),
(27, 28, 2, 'PE排', 'TMY-80*6', NULL, '0', '0.00', '0.00', NULL),
(28, 29, 2, '分母排', 'TMY-40*3', NULL, NULL, '0.00', NULL, NULL),
(29, 30, 2, '分母排', 'TMY-30*3', NULL, NULL, '0.00', NULL, NULL),
(30, 31, 2, '分支排', 'TMY-15*3', NULL, NULL, '0.00', NULL, NULL),
(31, 32, 2, '分支排', 'TMY-20*3', NULL, NULL, '0.00', NULL, NULL),
(32, 33, 2, '柜体', '1000*2200*600', NULL, NULL, '0.00', NULL, NULL),
(34, 34, 3, NULL, NULL, NULL, NULL, '0.00', NULL, NULL),
(35, 1, 6, '高压进线柜', 'KYN28A-12', '台', '0', '0.00', '46353.00', NULL),
(36, 2, 6, 'PT柜', 'KYN28A-12', '台', '0', '0.00', '46353.00', NULL),
(37, 3, 6, 'PT柜', 'KYN28A-12', '台', '0', '0.00', '46353.00', NULL),
(38, 5, 6, '刀开关', 'HD13BX-400/31 玻板', NULL, '0', '0.00', '0.00', NULL),
(39, 12, 6, '电流互感器', 'LMZJ1-0.5 50/5 一次穿心 3.0级', NULL, NULL, '0.00', NULL, NULL),
(40, 24, 6, '主母线框', 'ZMJ1-100*10', NULL, NULL, '0.00', NULL, NULL),
(41, 25, 6, 'N母线框', 'LMJ-80*10', '台', NULL, '0.00', NULL, NULL),
(42, 28, 6, 'PE排', 'TMY-80*6', NULL, NULL, '0.00', NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `yld_quo_pro_mater`
--

CREATE TABLE IF NOT EXISTS `yld_quo_pro_mater` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '产品id',
  `number` varchar(15) DEFAULT NULL COMMENT '元器件编号',
  `name` varchar(15) DEFAULT NULL COMMENT '元器件名称',
  `format` varchar(30) DEFAULT NULL COMMENT '元器件规格',
  `unit` varchar(5) DEFAULT NULL COMMENT '单位',
  `price` decimal(11,2) DEFAULT NULL COMMENT '单价',
  `num` decimal(11,1) DEFAULT NULL COMMENT '数量',
  `money` decimal(11,2) DEFAULT NULL COMMENT '小计',
  `mid` int(11) DEFAULT NULL,
  `total` decimal(11,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='报价单产品元器件' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_report`
--

CREATE TABLE IF NOT EXISTS `yld_report` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `oid` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL COMMENT '采购单id',
  `number` varchar(30) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL COMMENT '不合格品名称规格',
  `laiyuan` varchar(30) DEFAULT NULL COMMENT '来源',
  `num` varchar(30) DEFAULT NULL COMMENT '不合格数量',
  `optid` int(11) DEFAULT NULL COMMENT '操作人id',
  `optname` varchar(30) DEFAULT NULL COMMENT '操作人员',
  `optdt` datetime DEFAULT NULL COMMENT '操作时间',
  `hetong` varchar(50) DEFAULT NULL COMMENT '合同号或厂商',
  `faxian` varchar(30) DEFAULT NULL COMMENT '发现人员',
  `miaoshu` varchar(200) DEFAULT NULL COMMENT '不合格描述',
  `yaoqiu` varchar(200) DEFAULT NULL COMMENT '处置要求',
  `case` varchar(200) DEFAULT NULL COMMENT '原因分析',
  `zeren` varchar(200) DEFAULT NULL COMMENT '责任人',
  `cuoshi` varchar(200) DEFAULT NULL COMMENT '纠正措施',
  `csyy` varchar(200) DEFAULT NULL COMMENT '纠正措施验证',
  `yyuser` varchar(200) DEFAULT NULL COMMENT '验证人员',
  `yydt` datetime DEFAULT NULL COMMENT '验证时间',
  `del` tinyint(1) NOT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='不合格品处理报告' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_role`
--

CREATE TABLE IF NOT EXISTS `yld_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '角色id',
  `name` varchar(30) DEFAULT NULL COMMENT '角色名称',
  `promission` text,
  `shopid` int(9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='角色表' AUTO_INCREMENT=35 ;

--
-- 转存表中的数据 `yld_role`
--

INSERT INTO `yld_role` (`id`, `name`, `promission`, `shopid`) VALUES
(2, '管理员', '["258","259","260","261","2","14","15","251","4","240","242","288","5","241","279","280","281","282","3","262","277","276","275","274","272","271","270","269","268","267","266","278","243","252","244","250","6","245","287","246","247","7","248","285","284","283","273","256","255","254","253","249","286","8","257","263","264","265","1","9","10","11","12","238"]', 1),
(12, '技术人员', '["5","241"]', 1),
(13, '销售人员', '["4","240","242"]', 1),
(14, '质检人员', '["245","248","249","253","254","255"]', 1),
(15, '行政人员', '["258","259","260","261","3","266","267","268","269","270","271","272"]', 1),
(16, '采购人员', '["6","245","246","247"]', 1),
(17, '库房人员', '["8","257","263","264","265"]', 1),
(18, '行政部', '["258","259","260","261","3","262","277","276","275","274","272","271","270","269","268","267","266","278"]', 14),
(19, '生产技术部', '["5","241","279","280","281","282","243","252","244","250"]', 14),
(20, '采购部', '["6","245","287","246","247","8","257","263","264","265"]', 14),
(21, '质检部', '["7","248","285","284","283","273","256","255","254","253","249","286"]', 14),
(22, '销售部', '["4","240","242","288","1","10"]', 14),
(23, '行政部1', '["258","259","260","261","3","262","277","276","275","274","272","271","270","269","268","267","266","278"]', 18),
(24, '采购部2', '["6","245","287","246","247","8","257","263","264","265"]', 18),
(25, '生产技术部1', '["5","241","279","280","281","282","243","252","244","250"]', 18),
(26, '质检部1', '["7","248","285","284","283","273","256","255","254","253","249","286"]', 18),
(27, '销售部1', '["4","240","242","288"]', 18),
(28, '销售生产', '["4","240","242","288","243","252","244","250"]', 18),
(29, '总经理', '["258","259","260","261","2","14","15","251","4","240","242","288","5","241","279","280","281","282","3","262","277","276","275","274","272","271","270","269","268","267","266","278","243","252","244","250","6","245","287","246","247","7","248","285","284","283","273","256","255","254","253","249","286","8","257","263","264","265","1","9","10","11","12","238"]', 18),
(30, '行政部2', '["258","259","260","261","3","262","277","276","275","274","272","271","270","269","268","267","266","278"]', 19),
(31, '采购部3', '["6","245","287","246","247","8","257","263","264","265"]', 19),
(32, '生产部', '["5","241","279","280","281","282","243","252","244","250"]', 19),
(33, '质检部4', '["7","248","285","284","283","273","256","255","254","253","249","286"]', 19),
(34, '销售部', '["4","240","242","288","1","10"]', 19);

-- --------------------------------------------------------

--
-- 表的结构 `yld_ruku`
--

CREATE TABLE IF NOT EXISTS `yld_ruku` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL COMMENT '入库单名称',
  `number` varchar(30) DEFAULT NULL COMMENT '文件编号',
  `dt` varchar(30) DEFAULT NULL COMMENT '日期',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `oid` int(11) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_ruku_produce`
--

CREATE TABLE IF NOT EXISTS `yld_ruku_produce` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL COMMENT '名称',
  `format` varchar(30) DEFAULT NULL COMMENT '型号规格',
  `num` decimal(11,0) DEFAULT NULL,
  `supplier` varchar(30) DEFAULT NULL COMMENT '制造商/生产厂',
  `explain` varchar(50) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='入库单产品' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_sbbyjl`
--

CREATE TABLE IF NOT EXISTS `yld_sbbyjl` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `year` varchar(20) DEFAULT NULL COMMENT '年份',
  `name` varchar(50) DEFAULT NULL COMMENT '设备名称/型号',
  `person` varchar(20) DEFAULT NULL,
  `case` varchar(300) DEFAULT NULL COMMENT '异常情况记录',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_sbtz`
--

CREATE TABLE IF NOT EXISTS `yld_sbtz` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL COMMENT '标题',
  `number` varchar(30) DEFAULT NULL COMMENT '文件编号',
  `dt` varchar(30) DEFAULT NULL COMMENT '日期',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `uname` char(150) DEFAULT NULL COMMENT '签名',
  `cid` int(11) DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `format` varchar(30) DEFAULT NULL,
  `chang` varchar(30) DEFAULT NULL,
  `num` decimal(11,0) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `explain` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- 转存表中的数据 `yld_sbtz`
--

INSERT INTO `yld_sbtz` (`id`, `title`, `number`, `dt`, `optid`, `optname`, `optdt`, `status`, `uname`, `cid`, `del`, `name`, `format`, `chang`, `num`, `address`, `explain`) VALUES
(15, '', NULL, '2018-08-01 11:14:38', 88, '郑启勇', '2018-08-01 11:14:38', 1, NULL, 18, 0, '耐压测试仪', 'CC25', '可得仪器仪表', '1', '质检部', '');

-- --------------------------------------------------------

--
-- 表的结构 `yld_sbtz_log`
--

CREATE TABLE IF NOT EXISTS `yld_sbtz_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `sid` int(11) NOT NULL COMMENT '表单序号',
  `number` int(11) NOT NULL COMMENT '序号',
  `name` varchar(50) NOT NULL COMMENT '设备名称',
  `model` varchar(50) NOT NULL COMMENT '型号',
  `shang` varchar(50) NOT NULL COMMENT '设备制造商',
  `num` int(11) NOT NULL COMMENT '数量',
  `address` varchar(50) NOT NULL COMMENT '存放地址',
  `note` text NOT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_sbwxjh`
--

CREATE TABLE IF NOT EXISTS `yld_sbwxjh` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `bianzhi` varchar(200) DEFAULT NULL COMMENT '编制',
  `dt` varchar(30) DEFAULT NULL COMMENT '制表日期',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_sbwxjh_ch`
--

CREATE TABLE IF NOT EXISTS `yld_sbwxjh_ch` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '文件清单表id',
  `number` varchar(30) DEFAULT NULL COMMENT '设备编号',
  `name` varchar(50) DEFAULT NULL COMMENT '设备名称',
  `format` varchar(50) DEFAULT NULL COMMENT '型号规格',
  `level` varchar(20) DEFAULT NULL COMMENT '归档日期',
  `company` varchar(50) DEFAULT NULL COMMENT '生产厂家',
  `changsuo` varchar(50) DEFAULT NULL COMMENT '使用场所',
  `lastdt` varchar(50) DEFAULT NULL COMMENT '上次维修时间',
  `jhdt` varchar(50) DEFAULT NULL COMMENT '计划维修时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件清单副表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_sbxzjh`
--

CREATE TABLE IF NOT EXISTS `yld_sbxzjh` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `bianzhi` varchar(200) DEFAULT NULL COMMENT '编制',
  `dt` varchar(30) DEFAULT NULL COMMENT '部门',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='检测设备校准计划' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_sbxzjh_ch`
--

CREATE TABLE IF NOT EXISTS `yld_sbxzjh_ch` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '文件清单表id',
  `name` varchar(30) DEFAULT NULL COMMENT '计量器具名称',
  `keshi` varchar(10) DEFAULT NULL COMMENT '使用科室',
  `sum` varchar(50) DEFAULT NULL COMMENT '数量',
  `zhouqi` varchar(20) DEFAULT NULL COMMENT '检定周期',
  `m1` varchar(20) DEFAULT NULL COMMENT '一月',
  `m2` varchar(50) DEFAULT NULL,
  `m3` varchar(50) DEFAULT NULL,
  `m4` varchar(10) DEFAULT NULL,
  `m5` varchar(10) DEFAULT NULL,
  `m6` varchar(10) DEFAULT NULL,
  `m7` varchar(10) DEFAULT NULL,
  `m8` varchar(10) DEFAULT NULL,
  `m9` varchar(10) DEFAULT NULL,
  `m10` varchar(10) DEFAULT NULL,
  `m11` varchar(10) DEFAULT NULL,
  `m12` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='检测设备校准计划' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_sbyxjc`
--

CREATE TABLE IF NOT EXISTS `yld_sbyxjc` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL COMMENT '标题',
  `number` varchar(30) DEFAULT NULL COMMENT '文件编号',
  `dt` varchar(30) DEFAULT NULL COMMENT '日期',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `jielun` varchar(220) DEFAULT NULL COMMENT '结论',
  `uname` char(150) DEFAULT NULL COMMENT '签名',
  `cid` int(11) DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `val1` text,
  `val2` text,
  `val3` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_sbyxjc_log`
--

CREATE TABLE IF NOT EXISTS `yld_sbyxjc_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL COMMENT 'sbyxjc表的ID',
  `val1` varchar(50) NOT NULL COMMENT '实测值1',
  `val2` varchar(50) NOT NULL COMMENT '实测值2',
  `val3` varchar(50) NOT NULL COMMENT '实测值',
  `val4` varchar(50) NOT NULL,
  `val5` varchar(50) NOT NULL,
  `val6` varchar(50) NOT NULL,
  `val7` varchar(50) NOT NULL,
  `val8` varchar(50) NOT NULL,
  `val9` varchar(50) NOT NULL,
  `verdict1` varchar(200) NOT NULL COMMENT '结论',
  `verdict2` varchar(200) NOT NULL COMMENT '结论',
  `verdict3` varchar(200) NOT NULL COMMENT '结论',
  `uname1` varchar(50) NOT NULL COMMENT '检测员',
  `uname2` varchar(50) NOT NULL COMMENT '检测员',
  `uname3` varchar(50) NOT NULL COMMENT '检测员',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_seal`
--

CREATE TABLE IF NOT EXISTS `yld_seal` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL COMMENT '印章名称',
  `type` varchar(30) DEFAULT NULL COMMENT '印章类型',
  `uid` int(11) DEFAULT NULL COMMENT '保管人id',
  `uname` char(15) DEFAULT NULL COMMENT '保管人姓名',
  `image` varchar(100) DEFAULT NULL COMMENT '图片',
  `explain` varchar(200) DEFAULT NULL COMMENT '说明',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `shopid` int(11) DEFAULT NULL,
  `udeptname` varchar(30) DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `status` varchar(30) NOT NULL,
  `applydt` datetime DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='印章' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_sealapl`
--

CREATE TABLE IF NOT EXISTS `yld_sealapl` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '申请人id',
  `uname` char(15) DEFAULT NULL COMMENT '申请人姓名',
  `applydt` datetime DEFAULT NULL COMMENT '申请时间',
  `explain` varchar(500) DEFAULT NULL COMMENT '说明',
  `sealid` int(11) DEFAULT NULL COMMENT '印章id',
  `sealname` varchar(50) DEFAULT NULL COMMENT '印章名称',
  `isout` tinyint(1) DEFAULT NULL COMMENT '是否外带',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `optid` int(11) DEFAULT NULL COMMENT '操作人id',
  `optname` varchar(30) DEFAULT NULL COMMENT '操作人姓名',
  `optdt` datetime DEFAULT NULL COMMENT '操作时间',
  `shopid` int(11) DEFAULT NULL,
  `udeptname` varchar(30) DEFAULT NULL,
  `files` varchar(300) DEFAULT NULL,
  `del` tinyint(1) NOT NULL,
  `number` varchar(30) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_supplier`
--

CREATE TABLE IF NOT EXISTS `yld_supplier` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company` varchar(30) DEFAULT NULL COMMENT '供应商名称',
  `address` varchar(100) DEFAULT NULL COMMENT '地区',
  `goodstype` varchar(50) DEFAULT NULL COMMENT '供货商品类型',
  `name` varchar(10) DEFAULT NULL COMMENT '联系人',
  `phone` varchar(30) DEFAULT NULL,
  `explain` varchar(200) DEFAULT NULL,
  `optid` smallint(6) DEFAULT NULL,
  `optname` varchar(10) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `hfzm` tinyint(1) DEFAULT NULL COMMENT '是否有工商营业制造和其他合法证明   1有   0没有',
  `zlqk` tinyint(1) DEFAULT NULL COMMENT '质量情况  1强   2一般   3弱',
  `jgfw` tinyint(1) DEFAULT NULL COMMENT '产品价格和服务  1好   2一般  3差',
  `xgzz` tinyint(1) DEFAULT NULL COMMENT '产品相关资质   1 有    2,没有',
  `shxy` tinyint(1) DEFAULT NULL COMMENT '社会信誉是否良好    1好    2一般    3差',
  `cgst` tinyint(1) DEFAULT NULL COMMENT '采购部评定   1同意   2不同意',
  `cgname` varchar(100) DEFAULT NULL COMMENT '采购部评定人签名',
  `zjst` tinyint(1) DEFAULT NULL COMMENT '质检部评定   1同意   2不同意',
  `zjname` varchar(100) DEFAULT NULL COMMENT '质检部评定人签名',
  `scst` tinyint(1) DEFAULT NULL COMMENT '生产技术部评定    1同意   2不同意',
  `scname` varchar(100) DEFAULT NULL COMMENT '生产技术部评定人签名',
  `status` tinyint(1) DEFAULT NULL COMMENT '是否同意作为本公司合格供方    1同意    2不同意',
  `stdt` smallint(200) DEFAULT NULL COMMENT '批准日期',
  `del` tinyint(1) NOT NULL COMMENT '是否删除   1删除   0正常',
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='顾客档案' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_wjff`
--

CREATE TABLE IF NOT EXISTS `yld_wjff` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `bmq1` varchar(200) DEFAULT NULL COMMENT '编制',
  `bmq2` varchar(200) DEFAULT NULL COMMENT '审核',
  `bmq3` varchar(200) DEFAULT NULL,
  `bmq4` varchar(200) DEFAULT NULL,
  `bmq5` varchar(200) DEFAULT NULL,
  `bmq6` varchar(200) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件分发记录' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_wjff_ch`
--

CREATE TABLE IF NOT EXISTS `yld_wjff_ch` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `wid` int(11) DEFAULT NULL COMMENT '文件清单表id',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `banben` varchar(10) DEFAULT NULL COMMENT '版本',
  `name` varchar(50) DEFAULT NULL COMMENT '文件名称',
  `num` varchar(20) DEFAULT NULL COMMENT '分发号',
  `date` varchar(20) DEFAULT NULL COMMENT '分发日期',
  `explain` varchar(50) DEFAULT NULL COMMENT '回收记录',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件清单副表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_wjqd`
--

CREATE TABLE IF NOT EXISTS `yld_wjqd` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `bianzhi` varchar(200) DEFAULT NULL COMMENT '编制',
  `shenhe` varchar(200) DEFAULT NULL COMMENT '审核',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_wjqd_ch`
--

CREATE TABLE IF NOT EXISTS `yld_wjqd_ch` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `wid` int(11) DEFAULT NULL COMMENT '文件清单表id',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `banben` varchar(10) DEFAULT NULL COMMENT '版本',
  `name` varchar(50) DEFAULT NULL COMMENT '文件名称',
  `sxdt` varchar(20) DEFAULT NULL COMMENT '生效日期',
  `hsdt` varchar(20) DEFAULT NULL COMMENT '回收日期',
  `explain` varchar(50) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件清单副表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_wjxdsq`
--

CREATE TABLE IF NOT EXISTS `yld_wjxdsq` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `date` varchar(20) DEFAULT NULL COMMENT '日期',
  `wname` varchar(50) DEFAULT NULL COMMENT '文件名称',
  `wnumber` varchar(30) DEFAULT NULL COMMENT '文件编号',
  `type` enum('条款','页次','换版','取消') DEFAULT NULL COMMENT '修改性质',
  `dep` varchar(30) DEFAULT NULL COMMENT '归口部门',
  `case` varchar(500) DEFAULT NULL COMMENT '修改理由',
  `content` varchar(500) DEFAULT NULL COMMENT '修改内容',
  `fulu` varchar(200) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL COMMENT '检查人',
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件修订申请单' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_wlwj`
--

CREATE TABLE IF NOT EXISTS `yld_wlwj` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `bianzhi` varchar(200) DEFAULT NULL COMMENT '编制',
  `dep` varchar(30) DEFAULT NULL COMMENT '部门',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  `number` varchar(30) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `laiyuan` varchar(30) DEFAULT NULL,
  `gddt` varchar(20) DEFAULT NULL,
  `jsdep` varchar(30) DEFAULT NULL,
  `ffdep` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_wlwj_ch`
--

CREATE TABLE IF NOT EXISTS `yld_wlwj_ch` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `wid` int(11) DEFAULT NULL COMMENT '文件清单表id',
  `number` varchar(30) DEFAULT NULL COMMENT '编号',
  `type` varchar(10) DEFAULT NULL COMMENT '类别',
  `name` varchar(50) DEFAULT NULL COMMENT '文件名称',
  `laiyuan` varchar(20) DEFAULT NULL COMMENT '来源',
  `gddt` varchar(20) DEFAULT NULL COMMENT '归档日期',
  `jsdep` varchar(50) DEFAULT NULL COMMENT '接受部门',
  `ffdep` varchar(50) DEFAULT NULL COMMENT '分发部门',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件清单副表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_zxlog`
--

CREATE TABLE IF NOT EXISTS `yld_zxlog` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `oid` int(11) DEFAULT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(20) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `number` varchar(30) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='设备自校记录主表' AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_zxlog_log`
--

CREATE TABLE IF NOT EXISTS `yld_zxlog_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `format` varchar(30) DEFAULT NULL COMMENT '型号规格',
  `number` varchar(30) DEFAULT NULL COMMENT '设备编号',
  `content` varchar(300) DEFAULT NULL COMMENT '检验要求',
  `jieguo` varchar(10) DEFAULT NULL COMMENT '判定结果',
  `sign` varchar(200) DEFAULT NULL COMMENT '检测人员',
  `dt` date DEFAULT NULL COMMENT '检测时间',
  `explain` varchar(200) DEFAULT NULL COMMENT '备注',
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(20) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `sid` smallint(6) DEFAULT NULL COMMENT '设备id',
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_zxlog_shebei`
--

CREATE TABLE IF NOT EXISTS `yld_zxlog_shebei` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL COMMENT '设备名称',
  `day` decimal(6,0) NOT NULL COMMENT '检测周期',
  `yaoqiu` varchar(300) DEFAULT NULL COMMENT '检验要求',
  `del` tinyint(1) NOT NULL,
  `cid` smallint(6) NOT NULL,
  `number` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='设备自校记录副表' AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `yld_zxlog_shebei`
--

INSERT INTO `yld_zxlog_shebei` (`id`, `pid`, `name`, `day`, `yaoqiu`, `del`, `cid`, `number`) VALUES
(1, NULL, '综合试验台', '90', '操作灵活性,仪表,端子,线路,电压波动,重复动作', 0, 1, ''),
(2, NULL, '负载箱', '90', '操作灵活性,数显表20kW,数显表40kW,数显表80kW,数显表100kW,电路、配件', 0, 1, ''),
(3, NULL, 'IP检具', '90', '表面光滑无锈,IP检具1.0,IP检具2.5,IP检具12.5,,电路、配件', 0, 1, '');

-- --------------------------------------------------------

--
-- 表的结构 `yld_zztz`
--

CREATE TABLE IF NOT EXISTS `yld_zztz` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL COMMENT '标题',
  `bianzhi` varchar(200) DEFAULT NULL COMMENT '编制',
  `dep` varchar(30) DEFAULT NULL COMMENT '部门',
  `status` tinyint(1) NOT NULL,
  `del` tinyint(1) NOT NULL,
  `optid` int(11) DEFAULT NULL,
  `optname` varchar(30) DEFAULT NULL,
  `optdt` datetime DEFAULT NULL,
  `uname` varchar(200) DEFAULT NULL,
  `cid` smallint(6) DEFAULT NULL,
  `number` varchar(30) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `num` decimal(11,0) DEFAULT NULL,
  `ffdep` varchar(30) DEFAULT NULL,
  `qianshou` varchar(30) DEFAULT NULL,
  `dt` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='自制图纸记录表' AUTO_INCREMENT=11 ;

-- --------------------------------------------------------

--
-- 表的结构 `yld_zztz_ch`
--

CREATE TABLE IF NOT EXISTS `yld_zztz_ch` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '文件清单表id',
  `number` varchar(30) DEFAULT NULL COMMENT '图纸编号',
  `type` varchar(10) DEFAULT NULL COMMENT '产品类别',
  `name` varchar(50) DEFAULT NULL COMMENT '顾客/工程名称',
  `num` decimal(20,0) DEFAULT '1' COMMENT '页数',
  `ffdep` varchar(50) DEFAULT NULL COMMENT '分发部门',
  `qianshou` varchar(30) DEFAULT NULL COMMENT '签收人',
  `dt` varchar(30) DEFAULT NULL COMMENT '回收日期',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件清单副表' AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
