<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_devicedesc_check extends spModel{
    var $pk = "id";
    var $table = "devicedesc_check";
    
    
}

?>
