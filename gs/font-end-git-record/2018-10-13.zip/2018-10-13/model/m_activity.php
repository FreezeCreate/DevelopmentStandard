<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_activity extends spModel{
    var $pk = "id";
    var $table = "activity";
    
    
}

?>
