<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_cust_cate extends spModel{
    var $pk = "id";
    var $table = "cust_cate";
    
    
    
}

?>
