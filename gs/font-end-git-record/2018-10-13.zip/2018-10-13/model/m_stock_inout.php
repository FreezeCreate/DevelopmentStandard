<?php

/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_stock_inout extends spModel {

    var $pk = "id";
    var $table = "stock_inout";

}

?>
