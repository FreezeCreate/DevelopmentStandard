<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_wjqd extends spModel{
    var $pk = "id";
    var $table = "wjqd";
    
    
}

?>
