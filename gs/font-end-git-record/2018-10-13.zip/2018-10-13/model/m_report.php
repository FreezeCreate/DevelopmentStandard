<?php

/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_report extends spModel {

    var $pk = "id";
    var $table = "report";


}

?>
