<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_officeapl extends spModel{
    var $pk = "id";
    var $table = "officeapl";
    
    
    
}

?>
