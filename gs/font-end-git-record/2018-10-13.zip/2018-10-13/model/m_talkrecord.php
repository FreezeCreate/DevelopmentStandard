<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_talkrecord extends spModel{
    var $pk = "id";
    var $table = "talkrecord";
    
    
}

?>
