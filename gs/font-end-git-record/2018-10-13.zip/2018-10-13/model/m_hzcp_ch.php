<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_hzcp_ch extends spModel{
    var $pk = "id";
    var $table = "hzcp_ch";
    
    
}

?>
