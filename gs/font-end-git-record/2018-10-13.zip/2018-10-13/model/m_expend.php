<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_expend extends spModel{
    var $pk = "id";
    var $table = "expend";
    
    
}

?>
