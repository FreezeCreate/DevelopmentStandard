<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_pxjl_ch extends spModel{
    var $pk = "id";
    var $table = "pxjl_ch";
    
    
}

?>
