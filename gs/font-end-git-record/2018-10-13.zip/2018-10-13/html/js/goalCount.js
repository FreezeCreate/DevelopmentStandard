$(()=>{
    getPagesBox({
        nowUrl:"app.php/salegoal/goalCount",
        addList(data){
            console.log(data);
            if(data.code!=0){
                console.error(data.msg);
                return false;
            }
            var res=data.results,html='',i=0;
            if(!res)return fasle;
            for(var {id,salename,saledname,optdt,goaltitle,goalstatus} of res){
                i++;
                html+=`<tr>
                        <td>${i}</td>
                        <td>${saledname}</td>
                        <td>${salename}</td>
                        <td>${goaltitle}</td>
                        <td>${optdt}</td>
                        <td>${goalstatus==1?"已完成":"未完成"}</td>
                        <td>
                            <div class="colorBlu list-menu" style="display: inline-block;">
                                操作+
                                <ul class="menu">
                                    <li data-url="salegoal/goalItem.html?id=${id}" class="colorBlu menu-item NewPop" data-title="销售目标详情">
                                        <a href="#">查看详情</a>
                                    </li>
                                </ul>
                            </div>
                        </td>
                    </tr>`;
            }
            $("#dataList").html(html);
        }
    });
});