<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_sbxzjh_ch extends spModel{
    var $pk = "id";
    var $table = "sbxzjh_ch";
    
    
}

?>
