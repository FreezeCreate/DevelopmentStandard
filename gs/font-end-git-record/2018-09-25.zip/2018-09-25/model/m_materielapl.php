<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_materielapl extends spModel{
    var $pk = "id";
    var $table = "materielapl";
    
    
    
}

?>
