<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_manageuser extends spModel{
    var $pk = "id";
    var $table = "manageuser";
    
    
}

?>
