<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_clruku_produce extends spModel{
    var $pk = "id";
    var $table = "clruku_produce";
    
    
}

?>
