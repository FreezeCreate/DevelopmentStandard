<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_wjqd_ch extends spModel{
    var $pk = "id";
    var $table = "wjqd_ch";
    
    
}

?>
