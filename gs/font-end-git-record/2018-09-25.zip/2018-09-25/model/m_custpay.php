<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_custpay extends spModel{
    var $pk = "id";
    var $table = "custpay";
    
}

?>
