<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_wlwj_ch extends spModel{
    var $pk = "id";
    var $table = "wlwj_ch";
    
    
}

?>
