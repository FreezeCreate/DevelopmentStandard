<?php

class custpay extends AppController
{

    /**
     * 新增付款表信息 (Tips:选择客户数据是调用custmang/addmang接口)
     */
    function saveCustPay()
    {
        $admin           = $this->islogin();
        $model           = spClass('m_custpay');
        $id              = (int)htmlentities($this->spArgs('id'));
        
        $arg = array(
            'custumid'     => '客户id',
            'contractid'   => '合同id',
            'contractname' => '合同名称',
            'getmoney'     => '',
            'adddt'        => '付款单申请日期',
            'record'       => '款项情况',
            'files'        => '',
            'paytype'      => '付款方式',
            'saleid'       => '销售人员',
            'salename'     => '销售人员',
//             'status'       => '状态',   //1为结清；2为未结清
            'content'      => '',   //备注
        );
        $data = $this->receiveData($arg);
        
        $files = $this->spArgs('files');
        if($files) $data['files'] = implode(',', $files);
        $sum   = $model->findCount('paynumber like "%P'.date('Ymd').'%"');
        $sum   = $sum<9?'0'.($sum+1):($sum+1);
        
        $data['paynumber']  = 'P'.date('Ymd').$sum;    //p=>pay
        $data['adddt']   = date('Y-m-d H:i:s');
        $data['cid']     = $admin['cid'];
        $data['optid']   = $admin['id'];
        $data['optname'] = $admin['name'];
        $data['optdt']   = date('Y-m-d H:i:s');
        if($id){
            $data['status']  = $this->spArgs('status');   //1为结清；2为未结清
            $re = $model->find(array('id'=>$id,'del'=>0,'cid'=>$admin['cid']));
            if(empty($re)) $this->returnError('信息不存在');
            if($re['status'] == 1) $this->returnError('该款项已结清，不需要再操作');
            if(!empty($re['paynumber'])) unset($data['paynumber']);
            $up = $model->update(array('id'=>$id),$data);
        }else{
            $data['status']  = 2;   //1为结清；2为未结清
            $up = $model->create($data);
        }
        
        if($up) $this->returnSuccess('成功');
        $this->returnError('失败');
    }
    
    /**
     * 付款记录列表
     */
    function custPayLst()
    {
        $admin     = $this->islogin();
        $searchname = urldecode(htmlspecialchars($this->spArgs('searchname')));    //客户名称
        
        $m_contract = spClass('m_contract');
        $m_cust_pay = spClass('m_custpay');
        
        //where和分页where
        $con    = 'del = 0 and cid = ' . $admin['cid'];
        if (!empty($searchname)) {
            $con .= ' and concat(paynumber,custname,contractname,getmoney,adddt) like "%' . $searchname . '%"';
            $page_con['searchname'] = $searchname;
        }
        
        $results = $m_cust_pay->spPager($this->spArgs('page', 1), PAGE_NUM)->findAll($con,'optdt desc,id desc');
        $pager   = $m_cust_pay->spPager()->getPager();
        $result['pager'] = $pager;
        
        foreach($results as $k=>$v){
            $result['results'][$k] = $v;
//             array(
//                 'id'           => $v['id'],
//                 'custname'     => $v['custname'],
//                 'contractname' => $v['contractname'],
//                 'getmoney'     => $v['getmoney'],
//                 'optdt'        => $v['optdt'],
//                 'salename'     => $v['salename'],
//             );
        }
        
        $this->returnSuccess('成功', $result);
    }
    
    /**
     * 回款管理列表
     */
    function remonmang()
    {
        //合同信息+未收款信息
        $admin      = $this->islogin();
        $m_contract = spClass('m_contract');
        $m_custpay  = spClass('m_custpay');
        $salename   = urldecode(htmlspecialchars($this->spArgs('salename')));    //客户名称
        $number     = urldecode(htmlspecialchars($this->spArgs('number')));    //合同编号
        
        //按照客户姓名 + 合同编号搜索
        //where和分页where
        $con    = 'del = 0 and cid = ' . $admin['cid'];
        if (!empty($cust_name)) {
            $con .= ' and (salename like "%' . $salename . '%")';
            $page_con['salename'] = $salename;
        }
        if (!empty($number)) {
            $con .= ' and (number like "%' . $number . '%")';
            $page_con['number'] = $number;
        }
        
        $sale    = spClass('m_admin')->findAll('', 'id desc', 'id,username');
        
        $results = $m_contract->spPager($this->spArgs('page', 1), PAGE_NUM)->findAll($con,'optdt desc,id desc');
        $pager   = $m_contract->spPager()->getPager();
        $result['pager'] = $pager;
        
        $last_pay = $get_money = 0;
        foreach($results as $k=>$v){
            //余款数额
            $cust_pay  = $m_custpay->findAll('contractid='.$v['id']);
            foreach ($cust_pay as $cust_v){
                $last_pay  = $cust_v['getmoney'] + $last_pay;
            }
            
            $result['results'][$k] = array(
                'id'        => $v['id'],
                'number'    => $v['number'],
                'name'      => $v['name'],
                'salename'  => $v['salename'],
                'money'     => $v['money'],
                'factmoney' => $last_pay,
                'nothave'   => $v['money'] - $last_pay,
                'signdt'    => $v['signdt'],
                'startdt'   => $v['startdt'],
                'enddt'     => $v['enddt'],
                'explain'   => $v['explain'],
                'explain'   => $v['explain'],
                'status'    => $v['status'],
            );
        }
        
        $this->returnSuccess('成功', $result);
    }
    
    //del custpay info
    function delCustPay()
    {
        $admin = $this->islogin();
        $id = htmlspecialchars($this->spArgs('id'));
        $res = spClass('m_custpay')->update(array('id' => $id, 'cid' => $admin['cid']), array('del' => 1));
        if ($res){
            $this->returnSuccess('成功');
        }else {
            $this->returnError('失败');
        }
    }
    
    
    /**
     * 回款详情页
     */
    function remonmangInfo()
    {
        //合同信息+未收款信息
        $admin      = $this->islogin();
        $m_contract = spClass('m_contract');
        $m_custpay  = spClass('m_custpay');
        
        $id         = htmlspecialchars($this->spArgs('id'));
        //check params
        if (empty($id)) $this->returnError('id不存在');
        $results    = $m_contract->find('id='.$id.' and cid='.$admin['cid']);
        $pay_res    = $m_custpay->findAll('contractid='.$id.' and cid='.$admin['cid']);
        
        if (empty($results)) $this->returnError('id非法');
        $result['contract'] = $results;
        $result['custpay']  = $pay_res;
        
        $this->returnSuccess('成功', $result);
        
    }
    
    
}

