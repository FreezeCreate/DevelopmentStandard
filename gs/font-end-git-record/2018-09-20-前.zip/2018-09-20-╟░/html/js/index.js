$(()=>{
    $('.xzwj').click(function() {
        $('.upfile').click()
    })
    $(".NavMenuItem").click(function(){
        $("#LeftMenuBox").html(`<li>
            <a class="MenuItem active on NewHtml a_01"data-url="home.html"data-clas="a_01"data-img="images/shouye_39.png"data-name="首页"data-url="home.html">
                <i class="firstImg home_1"></i>
                <span class="firstText">首页</span>
            </a>
        </li>
        <div class='l_loading'></div>`);
        var that=$(this);
        var oid=that.data("oid");
        $.ajax({
            type:"get",
            data:{oid},
            url:dataURL+"main/menuLst",
            dataType:"json",
            success:function(data){
                console.log(data);
                if(data.code==0){
                    $(".l_loading").hide();
                }
                var res=data.results;
                for(var i=0,j=1,len=res.length;i<len;i++){
                    var html="";
                    if(res[i].pid==0){
                        j++;
                        html=`<li class="MenuGroup child-${res[i].id}">
                                <div class="MenuItem NewHtml" data-url="${res[i].control}/${res[i].way}.html" data-clas="a_${res[i].id}" data-name="${res[i].title}">
                                    <i class="firstImg home_${j}"></i>
                                    <span class="firstText">${res[i].title}</span>
                                </div>
                                <div class="GroupFirstBox">
                                </div>
                            </li>`;
                        $("#LeftMenuBox").append(html);
                    }else{
                        html=`<a class="Second NewHtml" data-url="${res[i].control}/${res[i].way}.html" data-clas="a_${res[i].id}" data-name="${res[i].title}">
                                <i class="firstImg home_01"></i>
                                <span class="firstText">${res[i].title}</span>
                            </a>`;
                        $(".MenuGroup").each(function(item,e){
                            var that=$(e);
                            if(that.hasClass(`child-${res[i].pid}`)){
                                that.children(".GroupFirstBox").append(html);
                                that.children(".MenuItem").addClass("GroupFirst").removeClass("MenuItem").removeClass("NewHtml");
                            }
                        });
                    }
                }            
            },
            error(){alert(101);}        
        });
    });
});