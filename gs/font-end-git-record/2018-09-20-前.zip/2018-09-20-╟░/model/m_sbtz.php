<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_sbtz extends spModel{
    var $pk = "id";
    var $table = "sbtz";
    
    
}

?>
