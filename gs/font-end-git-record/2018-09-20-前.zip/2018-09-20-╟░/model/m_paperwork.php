<?php

/**
 * Description of m_about
 *
 * @author Administrator
 */
class m_paperwork extends spModel {

    var $pk = "id";
    var $table = "paperwork";


}

?>
