<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_lcex extends spModel{
    var $pk = "id";
    var $table = "lcex";
    
    
}

?>
