<?php
/**
 * Description of m_user
 *
 * @author Administrator
 */
class m_bdly_ch extends spModel{
    var $pk = "id";
    var $table = "bdly_ch";
    
    
}

?>
